=== Floating Social & Contact Buttons ===
Contributors: alirezamoghimian
Tags: whatsapp, social media, contact buttons, floating button, telegram
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Floating contact and social buttons for WhatsApp, Telegram, phone, email and more, with responsive layouts and Elementor support.

== Description ==

Floating Social & Contact Buttons lets you add floating contact actions and social profile links to your WordPress website. Configure the layout, appearance, position, visibility rules, and links from the WordPress dashboard.

**Available contact and social channels include:**

* Phone, mobile, SMS, and email
* WhatsApp, Telegram, Messenger, Viber, Skype, and Discord
* Instagram, YouTube, LinkedIn, Facebook, X, TikTok, Threads, Pinterest, Snapchat, GitHub, Behance, Dribbble, Twitch, and Spotify
* Eitaa, Bale, Rubika, Soroush Plus, Gap, iGap, BisPhone, Aparat, and Cloob
* Google Maps, Waze, Neshan, and Balad directions
* Website links, FAQ, booking, order tracking, downloads, and custom links

**Main features:**

* Multiple floating layouts: panel, chat card, speed dial, side tabs, pill bar, single button, bubble, and full-width mobile bar
* Ready-made design templates and item styles
* Responsive position and size controls for desktop, tablet, and mobile
* Per-item colors, icon choices, labels, and custom links
* Font Awesome Free icons, Iranian service icons, custom SVG icons, and media-library images
* Display conditions for pages, posts, products, archives, WooCommerce pages, devices, users, business hours, delay, and scroll position
* Shortcode support: `[fscb]`
* Elementor widget when Elementor is active
* Optional inline display for contact items or social links (for example in a footer)
* JSON import and export
* Right-to-left and left-to-right support; ships with a Persian translation
* Optional click events for Google Analytics and Google Tag Manager
* Lightweight: icons are inlined as SVG, no icon font or external file is loaded on the front end

== Installation ==

1. Upload the `floating-social-contact-buttons` folder to the `/wp-content/plugins/` directory, or install the ZIP file through **Plugins > Add New Plugin > Upload Plugin**.
2. Activate **Floating Social & Contact Buttons** through the **Plugins** screen.
3. Open the **Social Buttons** menu in the WordPress dashboard.
4. Create a button group, configure its contact and social links, and save your settings.
5. Optionally use the `[fscb]` shortcode to place a configured group inside your content or a widget area.

== Frequently Asked Questions ==

= How do I display the floating buttons? =

Create and enable a button group in the plugin settings. The group is displayed according to its visibility settings. You can also use the `[fscb]` shortcode for inline placement.

= Can I display only social links with the shortcode? =

Yes. Use `[fscb id="YOUR_GROUP_ID" part="socials"]` to display only social links, or `part="items"` to display contact items only. Replace `YOUR_GROUP_ID` with the ID shown on the group card.

= Does it require Elementor? =

No. The plugin works without Elementor. The Elementor widget is available when Elementor is installed and active.

= Does the plugin contact external services? =

No. The plugin does not send any data to external servers and loads no external scripts, fonts, or images. The buttons are ordinary links to the services you configure (for example wa.me, t.me, or a map service); a request to those services is made only when a visitor clicks a button.

When "Send click events to Google Analytics / Tag Manager" is enabled, a click event is pushed to the `dataLayer` and `gtag()` functions that your site already loads. The plugin does not load Google Analytics or Google Tag Manager itself.

= Is it compatible with page caching? =

Yes. Device, schedule, delay, and scroll rules run in the browser, so they work behind full-page caches. After saving settings the plugin also clears the cache of WP Rocket, LiteSpeed Cache, W3 Total Cache, and WP Super Cache when they are active.

== Changelog ==

= 1.1.0 =
* Translation ready: all texts are in English with the `floating-social-contact-buttons` text domain; a complete Persian (fa_IR) translation is bundled (the plugin is shown as «سوشالیتو» in Persian WordPress).
* Admin screen follows the WordPress text direction (RTL and LTR).
* Security: stricter SVG sanitizer (DOM allowlist, only local `url(#id)` references, no URI schemes, size limit) and validation of color and font values.
* Unique `fscb` prefix for options, hooks, AJAX actions and the shortcode (`[fscb]`). Settings saved by earlier builds are migrated automatically and the old `[fcp]` shortcode keeps working on those sites.
* Icons from an optional pack fall back to Font Awesome when the pack is not present.
* Credits and license information for bundled icons.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.1.0 =
Translation-ready release with a bundled Persian translation and a stricter SVG sanitizer. Existing settings are migrated automatically.

== Credits ==

* Font Awesome Free 6 icons by Fonticons, Inc. — icons licensed under CC BY 4.0 (https://fontawesome.com/license/free). See `assets/icons/LICENSE.txt`.
* Iranian service and bank icons (`assets/icons/efa.json`) are converted from the icon font bundled with the Persian Elementor plugin by mohammadr3z (https://wordpress.org/plugins/persian-elementor/), licensed under GPLv2 or later.
* All brand names, logos and icons are trademarks of their respective owners and are used only to link to the corresponding service.
