<?php
/**
 * Plugin Name:       Floating Social & Contact Buttons
 * Description:       Add customizable floating contact and social buttons for WhatsApp, Telegram, phone, email, and more, with responsive layouts and Elementor support.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Alireza Moghimian
 * Author URI:        https://profiles.wordpress.org/alirezamoghimian/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       floating-social-contact-buttons
 * Domain Path:       /languages
 *
 * @package FloatingSocialContactButtons
 */

defined( 'ABSPATH' ) || exit;

define( 'FSCB_VERSION', '1.1.0' );
define( 'FSCB_FILE', __FILE__ );
define( 'FSCB_DIR', plugin_dir_path( __FILE__ ) );
define( 'FSCB_URL', plugin_dir_url( __FILE__ ) );
define( 'FSCB_OPTION', 'fscb_instances' );
define( 'FSCB_GLOBAL_OPTION', 'fscb_global' );

require_once FSCB_DIR . 'includes/class-fscb-networks.php';
require_once FSCB_DIR . 'includes/class-fscb-icons.php';
require_once FSCB_DIR . 'includes/class-fscb-settings.php';
require_once FSCB_DIR . 'includes/class-fscb-conditions.php';
require_once FSCB_DIR . 'includes/class-fscb-frontend.php';

/**
 * Load the bundled translations (Persian ships with the plugin; translate.wordpress.org packs take priority when available).
 */
function fscb_load_textdomain() {
	load_plugin_textdomain( 'floating-social-contact-buttons', false, dirname( plugin_basename( FSCB_FILE ) ) . '/languages' ); // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- bundled fa_IR translation.
}
add_action( 'init', 'fscb_load_textdomain' );

/**
 * One-time move of the settings saved by pre-release builds (option names were renamed to the fscb_ prefix).
 */
function fscb_migrate_legacy_options() {
	if ( get_option( 'fscb_db_version' ) ) {
		return;
	}
	$legacy = false;
	foreach ( array(
		'fcp_instances'    => 'fscb_instances',
		'fcp_global'       => 'fscb_global',
		'fcp_custom_icons' => 'fscb_custom_icons',
	) as $old => $new ) {
		$value = get_option( $old, null );
		if ( null !== $value && false === get_option( $new, false ) ) {
			update_option( $new, $value, 'fscb_instances' === $new );
			$legacy = true;
		}
	}
	if ( $legacy ) {
		update_option( 'fscb_legacy_shortcodes', 1, true );
	}
	update_option( 'fscb_db_version', FSCB_VERSION, true );
}
add_action( 'plugins_loaded', 'fscb_migrate_legacy_options', 5 );

if ( is_admin() ) {
	require_once FSCB_DIR . 'includes/class-fscb-admin.php';
	FSCB_Admin::init();
}

FSCB_Frontend::init();

/**
 * Register the Elementor widget when Elementor is active.
 *
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 */
function fscb_register_elementor_widget( $widgets_manager ) {
	require_once FSCB_DIR . 'includes/class-fscb-elementor-widget.php';
	$widgets_manager->register( new FSCB_Elementor_Widget() );
}
add_action( 'elementor/widgets/register', 'fscb_register_elementor_widget' );

/**
 * Create the settings option on activation.
 */
function fscb_activate() {
	fscb_migrate_legacy_options();
	if ( false === get_option( FSCB_OPTION ) ) {
		update_option( FSCB_OPTION, array(), true );
	}
}
register_activation_hook( __FILE__, 'fscb_activate' );

/**
 * Add a "Settings" link on the Plugins screen.
 *
 * @param string[] $links Existing action links.
 * @return string[]
 */
function fscb_action_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=fscb' ) ) . '">' . esc_html__( 'Settings', 'floating-social-contact-buttons' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'fscb_action_links' );
