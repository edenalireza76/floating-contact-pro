<?php
/**
 * Remove all plugin data on uninstall.
 *
 * @package FloatingSocialContactButtons
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'fscb_instances', 'fscb_global', 'fscb_custom_icons', 'fscb_icon_cache', 'fscb_db_version', 'fscb_legacy_shortcodes', 'fcp_instances', 'fcp_global', 'fcp_custom_icons', 'fcp_icon_cache' ) as $fscb_option ) {
	delete_option( $fscb_option );
}
