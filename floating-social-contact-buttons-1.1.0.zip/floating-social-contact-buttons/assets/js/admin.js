/* Floating Social & Contact Buttons – admin app (vanilla JS) */
(function (w, d) {
  'use strict';

  var I18N = w.wp.i18n, __ = I18N.__, _n = I18N._n, sprintf = I18N.sprintf;
  var A = w.FSCB_ADMIN, R = w.FSCB, TPL = w.FSCB_TEMPLATES || [], CATS = w.FSCB_TEMPLATE_CATS || {};
  var esc = R.esc;
  var app = d.getElementById('fcp-app');
  var PACKS = {}, packLoading = {};
  var S = {
    view: 'list', list: A.instances || [], cur: null, dirty: false, tab: 'layout',
    device: 'desktop', previewOpen: true, previewOffline: false, saving: false, openItems: {}
  };

  /* ================================================================ utils */

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function get(o, p) { return p.split('.').reduce(function (a, k) { return a == null ? undefined : a[k]; }, o); }
  function set(o, p, v) {
    var ks = p.split('.'), last = ks.pop();
    var t = ks.reduce(function (a, k) { if (a[k] == null || typeof a[k] !== 'object') a[k] = {}; return a[k]; }, o);
    t[last] = v;
  }
  function deepMerge(base, add) {
    Object.keys(add || {}).forEach(function (k) {
      var v = add[k];
      if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) deepMerge(base[k], v);
      else base[k] = clone(v);
    });
    return base;
  }
  function uid(p) { return (p || 'i') + Math.random().toString(36).slice(2, 8); }
  function rp(p) { return p.replace('@', S.device); }
  function $(sel, ctx) { return (ctx || d).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || d).querySelectorAll(sel)); }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function toast(msg, type) {
    var t = d.createElement('div'); t.className = 'fcp-toast fcp-toast--' + (type || 'ok'); t.dir = A.rtl ? 'rtl' : 'ltr'; t.textContent = msg;
    d.body.appendChild(t); setTimeout(function () { t.classList.add('is-in'); }, 10);
    setTimeout(function () { t.classList.remove('is-in'); setTimeout(function () { t.remove(); }, 300); }, 2600);
  }
  function ajax(action, data) {
    var fd = new FormData(); fd.append('action', 'fscb_' + action); fd.append('nonce', A.nonce);
    Object.keys(data || {}).forEach(function (k) { fd.append(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]); });
    return fetch(A.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }
  var ICON_SVG = {
    desktop: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 4h18a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-7v2h3v2H7v-2h3v-2H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm1 2v9h16V6z"/></svg>',
    tablet: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm0 2v16h12V4zm5 13h2v2h-2z"/></svg>',
    mobile: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm0 2v16h8V4zm3 13h2v2h-2z"/></svg>',
    drag: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M9 4a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM9 10a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm-6 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/></svg>'
  };
  var DEV_LABEL = { desktop: __('Desktop', 'floating-social-contact-buttons'), tablet: __('Tablet', 'floating-social-contact-buttons'), mobile: __('Mobile', 'floating-social-contact-buttons') };

  /* ================================================================ icons */

  function loadPack(p) {
    if (PACKS[p]) return Promise.resolve(PACKS[p]);
    if ((A.packs || []).indexOf(p) < 0) { PACKS[p] = {}; return Promise.resolve(PACKS[p]); }
    if (!packLoading[p]) {
      packLoading[p] = fetch(A.iconsUrl + p + '.json?v=' + A.version).then(function (r) { return r.json(); })
        .catch(function () { return {}; }).then(function (j) { PACKS[p] = j || {}; return PACKS[p]; });
    }
    return packLoading[p];
  }
  var EFA_FALLBACK = { 'efa:aparat': 'fas:circle-play', 'efa:neshan': 'fas:location-dot', 'efa:cloob': 'fas:users' };
  function svgFor(key) {
    if (!key || key.indexOf(':') < 0) return '';
    var i = key.indexOf(':'), p = key.slice(0, i), n = key.slice(i + 1);
    if (p === 'img') return '<img class="fcp-i fcp-i--img" src="' + esc(n) + '" alt="">';
    if (p === 'cus') { var c = A.custom[n]; return c ? c.svg.replace('<svg', '<svg class="fcp-i"') : ''; }
    var pack = PACKS[p];
    if ((!pack || !pack[n]) && p === 'efa') return svgFor(EFA_FALLBACK[key] || 'fas:comment-dots');
    if (!pack || !pack[n]) return '';
    var g = pack[n], wv = g[0], h = g[1], dd = g[2], t = g[3] || 0;
    if (t === 1) return '<svg class="fcp-i" viewBox="0 0 ' + wv + ' 1024"><path fill="currentColor" transform="matrix(1 0 0 -1 0 960)" d="' + dd + '"/></svg>';
    if (t === 2) return '<svg class="fcp-i" viewBox="0 0 ' + wv + ' ' + h + '"><path fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" d="' + dd + '"/></svg>';
    return '<svg class="fcp-i" viewBox="0 0 ' + wv + ' ' + h + '"><path fill="currentColor" d="' + dd + '"/></svg>';
  }
  function iconKeys(inst) {
    var keys = [inst.trigger.icon, inst.trigger.close_icon, inst.cta.icon, inst.header.icon, 'fas:xmark'];
    (inst.items || []).concat(inst.socials.items || []).forEach(function (it) { keys.push(it.icon || (A.networks[it.network] || {}).icon); });
    return keys.filter(Boolean);
  }
  function ensureIcons(inst) {
    var need = {};
    iconKeys(inst).forEach(function (k) { var p = k.split(':')[0]; if (['fas', 'far', 'fab', 'efa'].indexOf(p) > -1) { need[p] = 1; if (p === 'efa') need.fas = 1; } });
    return Promise.all(Object.keys(need).map(loadPack));
  }

  /** Mirror of FCP_Settings::payload() for the preview. */
  function payload(inst) {
    var p = clone(inst), icons = {};
    ['items', 'socials'].forEach(function (grp) {
      var list = grp === 'items' ? p.items : p.socials.items;
      list = (list || []).filter(function (it) { return it.enabled !== false; }).map(function (it) {
        var net = A.networks[it.network] || A.networks.custom;
        it.icon = it.icon || net.icon; it.ncolor = net.color; it.href = '#'; it.label = it.label || net.label;
        return it;
      });
      if (grp === 'items') p.items = list; else p.socials.items = list;
    });
    p.cta.href = '#';
    iconKeys(p).forEach(function (k) { icons[k] = svgFor(k); });
    p.icons = icons; p.i18n = A.i18n; p.bp = { tablet: +A.global.bp_tablet, mobile: +A.global.bp_mobile }; p.tz = 0;
    return p;
  }

  /* ============================================================ controls */

  function respBadge(isResp) {
    if (!isResp) return '';
    return '<span class="fcp-resp" title="' + esc(__('This setting is separate for each device', 'floating-social-contact-buttons')) + '">' + ICON_SVG[S.device] + '</span>';
  }
  function inherited(path) {
    if (path.indexOf('@') < 0 || S.device === 'desktop') return '';
    var parts = path.split('.@.'), map = get(S.cur, parts[0]);
    var prev = S.device === 'mobile' ? 'tablet' : 'desktop';
    var v = R.dev(map, prev)[parts[1]];
    return v === undefined ? '' : String(v);
  }
  function label(lbl, path, desc) {
    return '<div class="fcp-f__head"><label>' + lbl + respBadge(path && path.indexOf('@') > -1) + '</label></div>' + (desc ? '<p class="fcp-f__desc">' + desc + '</p>' : '');
  }
  var F = {
    text: function (path, lbl, o) {
      o = o || {};
      var v = get(S.cur, rp(path));
      return '<div class="fcp-f' + (o.wide ? ' fcp-f--wide' : '') + '">' + label(lbl, path, o.desc) +
        '<input type="text" class="fcp-in-text" data-path="' + path + '" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(o.ph || inherited(path)) + '"' + (o.ltr ? ' dir="ltr"' : '') + '></div>';
    },
    textarea: function (path, lbl, o) {
      o = o || {};
      return '<div class="fcp-f fcp-f--wide">' + label(lbl, path, o.desc) +
        '<textarea data-path="' + path + '" rows="' + (o.rows || 3) + '"' + (o.ltr ? ' dir="ltr" class="fcp-code"' : '') + ' placeholder="' + esc(o.ph || '') + '">' + esc(get(S.cur, rp(path)) || '') + '</textarea></div>';
    },
    num: function (path, lbl, o) {
      o = o || {};
      var v = get(S.cur, rp(path));
      var range = o.max != null ? '<input type="range" data-path="' + path + '" data-type="num" min="' + (o.min || 0) + '" max="' + o.max + '" step="' + (o.step || 1) + '" value="' + esc(v === '' || v == null ? (inherited(path) || o.min || 0) : v) + '">' : '';
      return '<div class="fcp-f">' + label(lbl, path, o.desc) + '<div class="fcp-num">' + range +
        '<input type="number" data-path="' + path + '" data-type="num" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(inherited(path)) + '" step="' + (o.step || 1) + '"' + (o.min != null ? ' min="' + o.min + '"' : '') + '>' +
        (o.unit ? '<span class="fcp-unit">' + o.unit + '</span>' : '') + '</div></div>';
    },
    select: function (path, lbl, opts, o) {
      o = o || {};
      var v = get(S.cur, rp(path)), inh = inherited(path);
      var html = (path.indexOf('@') > -1 && S.device !== 'desktop' ? '<option value="">— ' + sprintf(esc(/* translators: %s: device name (Desktop or Tablet). */ __('Same as %s', 'floating-social-contact-buttons')), (S.device === 'mobile' ? __('Tablet', 'floating-social-contact-buttons') : __('Desktop', 'floating-social-contact-buttons'))) + (inh ? ' (' + esc(optLabel(opts, inh)) + ')' : '') + ' —</option>' : '') +
        Object.keys(opts).map(function (k) { return '<option value="' + esc(k) + '"' + (String(v) === k ? ' selected' : '') + '>' + esc(opts[k]) + '</option>'; }).join('');
      return '<div class="fcp-f' + (o.wide ? ' fcp-f--wide' : '') + '">' + label(lbl, path, o.desc) + '<select data-path="' + path + '"' + (o.rerender ? ' data-rerender' : '') + (o.num ? ' data-type="num"' : '') + '>' + html + '</select></div>';
    },
    toggle: function (path, lbl, o) {
      o = o || {};
      var v = !!get(S.cur, rp(path));
      return '<div class="fcp-f fcp-f--toggle' + (o.wide ? ' fcp-f--wide' : '') + '"><label class="fcp-switch"><input type="checkbox" data-path="' + path + '" data-type="bool"' + (v ? ' checked' : '') + (o.rerender ? ' data-rerender' : '') + '><span></span></label><div><b>' + lbl + '</b>' + (o.desc ? '<p class="fcp-f__desc">' + o.desc + '</p>' : '') + '</div></div>';
    },
    color: function (path, lbl, o) {
      o = o || {};
      var v = get(S.cur, rp(path)) || '';
      var hex = /^#[0-9a-f]{6}$/i.test(v) ? v : (/^#[0-9a-f]{3}$/i.test(v) ? '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3] : '#ffffff');
      return '<div class="fcp-f fcp-f--color">' + label(lbl, path, o.desc) + '<div class="fcp-color"><span class="fcp-color__sw" style="background:' + esc(v || 'transparent') + '"><input type="color" data-color-for="' + path + '" value="' + hex + '"></span>' +
        '<input type="text" dir="ltr" data-path="' + path + '" value="' + esc(v) + '" placeholder="' + esc(o.ph || __('Default', 'floating-social-contact-buttons')) + '">' +
        (o.clear ? '<button type="button" class="fcp-mini" data-clear="' + path + '" title="' + esc(__('Clear', 'floating-social-contact-buttons')) + '">×</button>' : '') + '</div></div>';
    },
    icon: function (path, lbl, o) {
      o = o || {};
      var v = get(S.cur, rp(path)) || '', def = o.def || '';
      return '<div class="fcp-f">' + label(lbl, path, o.desc) + '<div class="fcp-iconf"><button type="button" class="fcp-iconf__btn" data-pick-icon="' + path + '" data-def="' + esc(def) + '">' +
        '<span class="fcp-iconf__prev">' + (svgFor(v || def) || '?') + '</span><span>' + (v ? esc(v) : (def ? __('Default', 'floating-social-contact-buttons') : __('Choose icon', 'floating-social-contact-buttons'))) + '</span></button>' +
        (v ? '<button type="button" class="fcp-mini" data-clear="' + path + '" title="' + esc(__('Delete', 'floating-social-contact-buttons')) + '">×</button>' : '') + '</div></div>';
    },
    image: function (path, lbl, o) {
      var v = get(S.cur, rp(path)) || '';
      return '<div class="fcp-f">' + label(lbl, path, (o || {}).desc) + '<div class="fcp-imgf">' + (v ? '<img src="' + esc(v) + '">' : '') +
        '<button type="button" class="button" data-media="' + path + '">' + esc(__('Choose image', 'floating-social-contact-buttons')) + '</button>' + (v ? '<button type="button" class="fcp-mini" data-clear="' + path + '">×</button>' : '') + '</div></div>';
    },
    choice: function (path, lbl, opts, o) {
      o = o || {};
      var v = get(S.cur, rp(path));
      return '<div class="fcp-f fcp-f--wide">' + label(lbl, path, o.desc) + '<div class="fcp-choice' + (o.cls ? ' ' + o.cls : '') + '">' + Object.keys(opts).map(function (k) {
        return '<button type="button" data-choice="' + path + '" data-value="' + esc(k) + '" class="' + (String(v) === k ? 'is-on' : '') + '"' + (o.rerender ? ' data-rerender' : '') + '>' + opts[k] + '</button>';
      }).join('') + '</div></div>';
    }
  };
  function optLabel(opts, v) { return opts[v] || v; }
  function sect(title, body, o) {
    o = o || {};
    return '<section class="fcp-sect"><h3>' + title + (o.badge ? ' <span class="fcp-tag">' + o.badge + '</span>' : '') + '</h3>' + (o.desc ? '<p class="fcp-sect__desc">' + o.desc + '</p>' : '') + '<div class="fcp-grid">' + body + '</div></section>';
  }
  function devSwitch() {
    return '<div class="fcp-devs">' + ['desktop', 'tablet', 'mobile'].map(function (k) {
      return '<button type="button" data-device="' + k + '" class="' + (S.device === k ? 'is-on' : '') + '" title="' + DEV_LABEL[k] + '">' + ICON_SVG[k] + '<span>' + DEV_LABEL[k] + '</span></button>';
    }).join('') + '</div>';
  }

  /* ================================================================ tabs */

  var LAYOUTS = {
    panel: [__('Card/list panel', 'floating-social-contact-buttons'), __('Full panel with header, items, social links and a button', 'floating-social-contact-buttons')],
    chat: [__('Chat bubble', 'floating-social-contact-buttons'), __('Chat card with an agent avatar', 'floating-social-contact-buttons')],
    speeddial: [__('Floating menu', 'floating-social-contact-buttons'), __('Vertical round icons', 'floating-social-contact-buttons')],
    tabs: [__('Side tabs', 'floating-social-contact-buttons'), __('Tabs attached to the screen edge', 'floating-social-contact-buttons')],
    pill: [__('Pill bar', 'floating-social-contact-buttons'), __('Icons in a single pill', 'floating-social-contact-buttons')],
    cta: [__('Single text button', 'floating-social-contact-buttons'), __('One button with an icon and text', 'floating-social-contact-buttons')],
    bubble: [__('Single icon', 'floating-social-contact-buttons'), __('One direct round button', 'floating-social-contact-buttons')],
    bar: [__('Full-width bar', 'floating-social-contact-buttons'), __('Bottom/top bar of the screen (mobile)', 'floating-social-contact-buttons')]
  };
  var HAS_TRIGGER = { panel: 1, chat: 1, speeddial: 1 };

  var TABS = [
    ['layout', __('Template & layout', 'floating-social-contact-buttons')], ['items', __('Contact items', 'floating-social-contact-buttons')], ['socials', __('Social networks', 'floating-social-contact-buttons')], ['texts', __('Header & texts', 'floating-social-contact-buttons')],
    ['trigger', __('Main button', 'floating-social-contact-buttons')], ['position', __('Position', 'floating-social-contact-buttons')], ['size', __('Sizes', 'floating-social-contact-buttons')], ['colors', __('Colors & style', 'floating-social-contact-buttons')],
    ['display', __('Display conditions', 'floating-social-contact-buttons')], ['advanced', __('Advanced', 'floating-social-contact-buttons')]
  ];

  var T = {};

  T.layout = function () {
    var L = S.cur.layout;
    var cards = Object.keys(LAYOUTS).map(function (k) {
      return '<button type="button" class="fcp-layout' + (L === k ? ' is-on' : '') + '" data-choice="layout" data-value="' + k + '" data-rerender>' +
        '<span class="fcp-layout__art fcp-art--' + k + '"><i></i><i></i><i></i></span><b>' + LAYOUTS[k][0] + '</b><small>' + LAYOUTS[k][1] + '</small></button>';
    }).join('');
    var h = sect(__('Display type', 'floating-social-contact-buttons'), '<div class="fcp-layouts fcp-f--wide">' + cards + '</div>' +
      '<div class="fcp-f--wide fcp-tplbar"><button type="button" class="button button-secondary" data-open-gallery="apply">🎨 ' + sprintf(esc(/* translators: %d: number of templates. */ __('Choose from %d ready-made templates…', 'floating-social-contact-buttons')), TPL.length) + '</button><span class="fcp-f__desc">' + esc(__('Templates apply colors, layout and style; you can keep your current items.', 'floating-social-contact-buttons')) + '</span></div>');

    if (L === 'panel') {
      h += sect(__('Panel layout', 'floating-social-contact-buttons'), F.choice('opts.item_style', __('Item style', 'floating-social-contact-buttons'), {
        card: __('Card', 'floating-social-contact-buttons'), row: __('Simple list', 'floating-social-contact-buttons'), tinted: __('Soft color', 'floating-social-contact-buttons'), solid: __('Solid color', 'floating-social-contact-buttons'), grid: __('Grid', 'floating-social-contact-buttons'), minimal: __('Minimal', 'floating-social-contact-buttons')
      }, { rerender: true }) +
        (S.cur.opts.item_style === 'grid' ? F.num('opts.columns', __('Number of columns', 'floating-social-contact-buttons'), { min: 2, max: 4 }) : '') +
        F.select('opts.close_style', __('Close button', 'floating-social-contact-buttons'), { outside: __('Separate square above the panel', 'floating-social-contact-buttons'), inside: __('Inside the header', 'floating-social-contact-buttons'), trigger: __('Turn the main button into ×', 'floating-social-contact-buttons') }) +
        F.toggle('opts.show_value', __('Show the number/value under the title', 'floating-social-contact-buttons'), { desc: __('e.g. “09011098899” under “Sales advice”', 'floating-social-contact-buttons') }) +
        F.toggle('opts.value_ltr', __('Left-to-right numbers', 'floating-social-contact-buttons'), { desc: __('Displays numbers like 021-2201... correctly', 'floating-social-contact-buttons') }) +
        F.toggle('cta.show', __('Call-to-action (CTA) button at the bottom of the panel', 'floating-social-contact-buttons'), { rerender: true }));
    }
    if (L === 'chat') {
      h += sect(__('Chat layout', 'floating-social-contact-buttons'), F.select('opts.chat_mode', __('Card footer', 'floating-social-contact-buttons'), { button: __('One large button', 'floating-social-contact-buttons'), icons: __('Messenger icons (“Start a chat with…”)', 'floating-social-contact-buttons'), list: __('Item list', 'floating-social-contact-buttons') }, { rerender: true }) +
        F.select('opts.close_style', __('Close button', 'floating-social-contact-buttons'), { inside: __('Inside the header', 'floating-social-contact-buttons'), outside: __('Separate square above the card', 'floating-social-contact-buttons'), trigger: __('Turn the main button into ×', 'floating-social-contact-buttons') }));
    }
    if (L === 'speeddial') {
      h += sect(__('Floating menu', 'floating-social-contact-buttons'), F.select('opts.dial_labels', __('Labels next to icons', 'floating-social-contact-buttons'), { always: __('Always', 'floating-social-contact-buttons'), hover: __('On hover only', 'floating-social-contact-buttons'), none: __('No labels', 'floating-social-contact-buttons') }) +
        F.select('opts.close_style', __('When opened', 'floating-social-contact-buttons'), { trigger: __('Main button turns into ×', 'floating-social-contact-buttons'), inside: __('Icon stays the same', 'floating-social-contact-buttons') }));
    }
    if (L === 'tabs') h += sect(__('Tabs', 'floating-social-contact-buttons'), F.select('opts.tabs_expand', __('Show title', 'floating-social-contact-buttons'), { hover: __('Open on hover', 'floating-social-contact-buttons'), always: __('Always open', 'floating-social-contact-buttons') }));
    if (L === 'pill') h += sect(__('Pill bar', 'floating-social-contact-buttons'), F.toggle('opts.pill_labels', __('Show the title under the icons', 'floating-social-contact-buttons')));
    if (L === 'bar') h += sect(__('Full-width bar', 'floating-social-contact-buttons'), F.select('opts.bar_mode', __('Mode', 'floating-social-contact-buttons'), { icons: __('Equal buttons with icon and title', 'floating-social-contact-buttons'), cta: __('One large button (CTA)', 'floating-social-contact-buttons') }, { rerender: true }));
    if (L === 'cta' || L === 'bar' && S.cur.opts.bar_mode === 'cta' || (L === 'panel' && S.cur.cta.show) || L === 'chat') {
      var itemOpts = { '': __('— First contact item —', 'floating-social-contact-buttons') };
      (S.cur.items || []).forEach(function (it) { itemOpts[it.id] = (it.label || (A.networks[it.network] || {}).label) + ' (' + (it.value || '') + ')'; });
      h += sect(__('Call-to-action (CTA) button', 'floating-social-contact-buttons'), F.text('cta.text', __('Button text', 'floating-social-contact-buttons')) + F.icon('cta.icon', __('Button icon', 'floating-social-contact-buttons')) +
        F.select('cta.item', __('Link to item', 'floating-social-contact-buttons'), itemOpts) + F.text('cta.link', __('Or a custom link', 'floating-social-contact-buttons'), { ltr: true, ph: 'https://...', desc: __('If filled, it is used instead of the item.', 'floating-social-contact-buttons') }));
    }
    if (L === 'bubble') h += sect(__('Single icon', 'floating-social-contact-buttons'), '<p class="fcp-f--wide fcp-note">' + esc(__('The button links directly to the', 'floating-social-contact-buttons')) + ' <b>' + esc(__('first contact item', 'floating-social-contact-buttons')) + '</b> ' + esc(__('. Set the icon and color in the “Main button” tab.', 'floating-social-contact-buttons')) + '</p>');
    return h;
  };

  function networkSelect(path, val) {
    var groups = {};
    Object.keys(A.networks).forEach(function (k) { var n = A.networks[k]; (groups[n.group] = groups[n.group] || []).push([k, n.label]); });
    return '<select data-path="' + path + '" data-rerender-item>' + Object.keys(groups).map(function (g) {
      return '<optgroup label="' + esc(g) + '">' + groups[g].map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === val ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</optgroup>';
    }).join('') + '</select>';
  }
  var KIND_HINT = {
    phone: [__('Number', 'floating-social-contact-buttons'), __('09121234567 or 021-12345678', 'floating-social-contact-buttons'), __('For WhatsApp/Viber the leading zero is converted to the country code automatically.', 'floating-social-contact-buttons')],
    user: [__('Username or link', 'floating-social-contact-buttons'), __('@username or full link', 'floating-social-contact-buttons'), __('You can also enter a full link.', 'floating-social-contact-buttons')],
    url: [__('Link', 'floating-social-contact-buttons'), 'https://...', ''],
    email: [__('Email', 'floating-social-contact-buttons'), 'info@example.com', ''],
    text: [__('Address or coordinates', 'floating-social-contact-buttons'), __('10 Main Street, City … or 35.7,51.4', 'floating-social-contact-buttons'), '']
  };

  function itemRow(group, i, it) {
    var base = group + '.' + i, net = A.networks[it.network] || A.networks.custom, kind = KIND_HINT[net.kind] || KIND_HINT.url;
    var key = group + ':' + it.id, open = !!S.openItems[key];
    var msgLbl = { whatsapp: __('Default WhatsApp message', 'floating-social-contact-buttons'), sms: __('SMS text', 'floating-social-contact-buttons'), email: __('Email subject', 'floating-social-contact-buttons') }[it.network];
    var isSoc = group === 'socials.items';
    return '<div class="fcp-rep__item' + (open ? ' is-open' : '') + (it.enabled === false ? ' is-off' : '') + '" draggable="false" data-rep="' + group + '" data-idx="' + i + '">' +
      '<div class="fcp-rep__head" data-toggle-item="' + key + '"><span class="fcp-rep__drag" title="' + esc(__('Move', 'floating-social-contact-buttons')) + '">' + ICON_SVG.drag + '</span>' +
      '<span class="fcp-rep__ic" style="background:' + esc(it.color || net.color) + '">' + svgFor(it.icon || net.icon) + '</span>' +
      '<span class="fcp-rep__title"><b>' + esc(it.label || net.label) + '</b><small dir="ltr">' + esc(it.value || '—') + '</small></span>' +
      '<label class="fcp-switch fcp-switch--sm" title="' + esc(__('Enable/disable', 'floating-social-contact-buttons')) + '"><input type="checkbox" data-path="' + base + '.enabled" data-type="bool"' + (it.enabled !== false ? ' checked' : '') + ' data-rerender-item><span></span></label>' +
      '<button type="button" class="fcp-mini" data-dup="' + group + '" data-idx="' + i + '" title="' + esc(__('Duplicate', 'floating-social-contact-buttons')) + '">⧉</button>' +
      '<button type="button" class="fcp-mini fcp-mini--del" data-del="' + group + '" data-idx="' + i + '" title="' + esc(__('Delete', 'floating-social-contact-buttons')) + '">🗑</button></div>' +
      (open ? '<div class="fcp-rep__body fcp-grid">' +
        '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('Type / network', 'floating-social-contact-buttons')) + '</label></div>' + networkSelect(base + '.network', it.network) + '</div>' +
        F.text(base + '.value', kind[0], { ltr: true, ph: kind[1], desc: kind[2] }) +
        F.text(base + '.label', __('Title', 'floating-social-contact-buttons'), { ph: net.label }) +
        (isSoc ? '' : F.text(base + '.sub', __('Subtitle (optional)', 'floating-social-contact-buttons'), { ph: __('e.g. Replies within 10 minutes', 'floating-social-contact-buttons') })) +
        (msgLbl ? F.textarea(base + '.message', msgLbl, { rows: 2 }) : '') +
        F.icon(base + '.icon', __('Icon', 'floating-social-contact-buttons'), { def: net.icon }) +
        F.color(base + '.color', __('Icon background color', 'floating-social-contact-buttons'), { clear: true, ph: __('From the global style', 'floating-social-contact-buttons') }) +
        F.color(base + '.icon_color', __('Icon color', 'floating-social-contact-buttons'), { clear: true, ph: __('From the global style', 'floating-social-contact-buttons') }) +
        (isSoc ? '' : F.color(base + '.bg', __('Card background color', 'floating-social-contact-buttons'), { clear: true, ph: __('From the global style', 'floating-social-contact-buttons') })) +
        F.toggle(base + '.new_tab', __('Open in a new tab', 'floating-social-contact-buttons')) +
        '</div>' : '') + '</div>';
  }

  function repeater(group, title) {
    var list = get(S.cur, group) || [];
    return '<div class="fcp-rep" data-rep-list="' + group + '">' + (list.length ? list.map(function (it, i) { return itemRow(group, i, it); }).join('') : '<p class="fcp-empty">' + esc(__('No items added yet.', 'floating-social-contact-buttons')) + '</p>') + '</div>' +
      '<div class="fcp-rep__add"><select data-add-net="' + group + '"><option value="">' + esc(__('+ Add', 'floating-social-contact-buttons')) + ' ' + title + '…</option>' +
      networkSelect('', '').replace(/^<select[^>]*>/, '').replace(/<\/select>$/, '').replace(/ selected/g, '') + '</select>' +
      '<span class="fcp-f__desc">' + esc(__('Drag items to reorder them.', 'floating-social-contact-buttons')) + '</span></div>';
  }

  T.items = function () {
    var note = { tabs: __('Each item is a tab.', 'floating-social-contact-buttons'), pill: __('Each item is an icon in the bar.', 'floating-social-contact-buttons'), bubble: __('Only the first item is used.', 'floating-social-contact-buttons'), cta: __('The CTA links to the first item (or the selected item).', 'floating-social-contact-buttons') }[S.cur.layout];
    return sect(__('Contact items', 'floating-social-contact-buttons'), '<div class="fcp-f--wide">' + repeater('items', __('Contact item', 'floating-social-contact-buttons')) + '</div>', { desc: note || __('Phone, WhatsApp, Eitaa, Bale, Rubika, Telegram, email, map, link… as many as you like.', 'floating-social-contact-buttons') });
  };
  T.socials = function () {
    return sect(__('Social networks row', 'floating-social-contact-buttons'), F.toggle('socials.show', __('Show the social networks row at the bottom of the panel', 'floating-social-contact-buttons')) + F.text('socials.title', __('Row title', 'floating-social-contact-buttons')) +
      F.select('socials.shape', __('Icon shape', 'floating-social-contact-buttons'), { rounded: __('Rounded', 'floating-social-contact-buttons'), circle: __('Circle', 'floating-social-contact-buttons'), square: __('Square', 'floating-social-contact-buttons'), outline: __('Outline', 'floating-social-contact-buttons') }) +
      '<div class="fcp-f--wide">' + repeater('socials.items', __('Social network', 'floating-social-contact-buttons')) + '</div>', { desc: __('This row appears in the panel and in the “Social networks only” widget/shortcode (for example in the footer).', 'floating-social-contact-buttons') });
  };

  T.texts = function () {
    var L = S.cur.layout;
    if (L === 'chat') {
      return sect(__('Chat card', 'floating-social-contact-buttons'), F.image('header.avatar', __('Agent photo', 'floating-social-contact-buttons')) + F.icon('header.icon', __('Or an icon instead of a photo', 'floating-social-contact-buttons')) +
        F.text('header.agent', __('Agent name', 'floating-social-contact-buttons')) + F.text('header.role', __('Role', 'floating-social-contact-buttons'), { ph: __('Sales consultant', 'floating-social-contact-buttons') }) +
        F.textarea('header.message', __('Welcome message', 'floating-social-contact-buttons')) + F.text('header.time', __('Displayed time', 'floating-social-contact-buttons'), { ph: '10:30' }) +
        F.toggle('header.online', __('Green “online” dot', 'floating-social-contact-buttons')));
    }
    return sect(__('Panel header', 'floating-social-contact-buttons'), F.toggle('header.show', __('Show header', 'floating-social-contact-buttons'), { rerender: true }) + F.text('header.title', __('Title', 'floating-social-contact-buttons')) + F.text('header.subtitle', __('Subtitle', 'floating-social-contact-buttons')) +
      F.icon('header.icon', __('Icon next to the title (optional)', 'floating-social-contact-buttons')), { desc: L === 'panel' ? '' : __('The header is only used in the “Panel” layout and the inline widget.', 'floating-social-contact-buttons') });
  };

  T.trigger = function () {
    var L = S.cur.layout;
    if (!HAS_TRIGGER[L] && L !== 'bubble' && L !== 'cta') {
      return sect(__('Main button', 'floating-social-contact-buttons'), '<p class="fcp-note fcp-f--wide">' + esc(__('This layout has no open/close button; the background color comes from “Main button color” in the Colors tab.', 'floating-social-contact-buttons')) + '</p>');
    }
    var h = sect(__('Icon & shape', 'floating-social-contact-buttons'), (L !== 'cta' ? F.icon('trigger.icon', __('Button icon', 'floating-social-contact-buttons')) : '') +
      (HAS_TRIGGER[L] ? F.icon('trigger.close_icon', __('Close icon', 'floating-social-contact-buttons'), { def: 'fas:xmark' }) : '') +
      F.choice('trigger.shape', __('Shape', 'floating-social-contact-buttons'), { circle: __('Circle', 'floating-social-contact-buttons'), rounded: __('Rounded corners', 'floating-social-contact-buttons'), square: __('Square', 'floating-social-contact-buttons'), pill: __('Pill', 'floating-social-contact-buttons') }) +
      (L !== 'cta' ? F.text('trigger.label', __('Text next to the icon (optional)', 'floating-social-contact-buttons'), { ph: __('Contact us', 'floating-social-contact-buttons') }) + F.toggle('trigger.label_show', __('Show text next to the icon', 'floating-social-contact-buttons')) : '') +
      F.text('trigger.tooltip', __('Accessibility text (aria-label)', 'floating-social-contact-buttons'), { ph: __('Contact us', 'floating-social-contact-buttons') }));
    h += sect(__('Effects', 'floating-social-contact-buttons'), F.toggle('trigger.pulse', __('Pulsing ring around the button', 'floating-social-contact-buttons')) +
      (L !== 'cta' ? F.select('trigger.animate', __('Icon animation', 'floating-social-contact-buttons'), { rotate: __('Rotate when opening', 'floating-social-contact-buttons'), shake: __('Bell shake', 'floating-social-contact-buttons'), bounce: __('Bounce', 'floating-social-contact-buttons'), none: __('No animation', 'floating-social-contact-buttons') }) : '') +
      F.toggle('trigger.badge_show', __('Notification badge', 'floating-social-contact-buttons'), { rerender: true }) + (S.cur.trigger.badge_show ? F.text('trigger.badge_text', __('Badge text', 'floating-social-contact-buttons')) : ''));
    h += sect(__('Welcome message (bubble next to the button)', 'floating-social-contact-buttons'), F.toggle('trigger.greet_show', __('Show welcome message', 'floating-social-contact-buttons'), { rerender: true }) +
      (S.cur.trigger.greet_show ? F.textarea('trigger.greet_text', __('Message text', 'floating-social-contact-buttons'), { rows: 2 }) + F.num('trigger.greet_delay', __('Show after', 'floating-social-contact-buttons'), { min: 0, max: 60, unit: __('seconds', 'floating-social-contact-buttons') }) : ''),
      { desc: __('Shown once per session and closed with a click.', 'floating-social-contact-buttons') });
    if (HAS_TRIGGER[L]) {
      h += sect(__('Behavior', 'floating-social-contact-buttons'), F.select('trigger.open_on', __('Open on', 'floating-social-contact-buttons'), { click: __('Click', 'floating-social-contact-buttons'), hover: __('Hover (desktop only)', 'floating-social-contact-buttons') }) +
        F.num('trigger.auto_open', __('Open automatically after', 'floating-social-contact-buttons'), { min: 0, max: 120, unit: __('seconds', 'floating-social-contact-buttons'), desc: __('0', 'floating-social-contact-buttons') + ' = ' + __('Disabled. Once per session.', 'floating-social-contact-buttons') }) +
        F.toggle('opts.close_outside', __('Close when clicking outside the panel', 'floating-social-contact-buttons')) + F.toggle('opts.overlay', __('Dim the background while open', 'floating-social-contact-buttons')));
    }
    return h;
  };

  var PLACES = {
    'top-left': '↖', 'top-center': '↑', 'top-right': '↗',
    'middle-left': '←', 'middle-center': '', 'middle-right': '→',
    'bottom-left': '↙', 'bottom-center': '↓', 'bottom-right': '↘'
  };
  T.position = function () {
    var path = 'position.@.place', cur = get(S.cur, rp(path)), inh = R.dev(S.cur.position, S.device).place;
    var grid = '<div class="fcp-place">' + Object.keys(PLACES).map(function (k) {
      if (k === 'middle-center') return '<span class="fcp-place__mid">' + esc(__('Screen', 'floating-social-contact-buttons')) + '</span>';
      return '<button type="button" data-choice="' + path + '" data-value="' + k + '" class="' + (cur === k ? 'is-on' : (!cur && inh === k ? 'is-inh' : '')) + '" title="' + k + '">' + PLACES[k] + '</button>';
    }).join('') + '</div>';
    var h = sect(__('Placement on the screen', 'floating-social-contact-buttons'), '<div class="fcp-f fcp-f--wide">' + label(__('Corner / edge of the screen', 'floating-social-contact-buttons'), path) + grid +
      (S.device !== 'desktop' ? '<button type="button" class="button-link" data-clear="' + path + '">' + sprintf(esc(/* translators: %s: device name (Desktop or Tablet). */ __('Use the %s setting', 'floating-social-contact-buttons')), (S.device === 'mobile' ? __('Tablet', 'floating-social-contact-buttons') : __('Desktop', 'floating-social-contact-buttons'))) + '</button>' : '') + '</div>' +
      F.num('position.@.x', __('Horizontal distance from the edge', 'floating-social-contact-buttons'), { min: -50, max: 300, unit: 'px' }) +
      F.num('position.@.y', __('Vertical distance from the edge', 'floating-social-contact-buttons'), { min: -50, max: 400, unit: 'px' }) +
      F.num('advanced.z', __('z-index (layer)', 'floating-social-contact-buttons'), { desc: __('If it goes under a sticky header or a theme popup, increase the number.', 'floating-social-contact-buttons') }),
      { desc: __('Can be set separately for each device — use the desktop/tablet/mobile buttons above the preview.', 'floating-social-contact-buttons') + ' ' + (S.cur.layout === 'bar' ? __('The full-width bar only uses top/bottom.', 'floating-social-contact-buttons') : '') });
    h += sect(__('Theme compatibility', 'floating-social-contact-buttons'), F.toggle('advanced.woodmart_offset', __('Above the WoodMart mobile sticky toolbar', 'floating-social-contact-buttons'), { desc: __('When the WoodMart “Sticky toolbar” is on, the buttons move up 62px automatically.', 'floating-social-contact-buttons') }));
    return h;
  };

  T.size = function () {
    var L = S.cur.layout;
    var h = sect(__('Button & icons', 'floating-social-contact-buttons'),
      F.num('size.@.trigger', HAS_TRIGGER[L] || L === 'bubble' ? __('Main button size', 'floating-social-contact-buttons') : __('Button height', 'floating-social-contact-buttons'), { min: 32, max: 110, unit: 'px' }) +
      F.num('size.@.icon', __('Button icon size', 'floating-social-contact-buttons'), { min: 12, max: 60, unit: 'px' }) +
      F.num('size.@.item_icon', __('Item icon box size', 'floating-social-contact-buttons'), { min: 24, max: 80, unit: 'px' }) +
      F.num('size.@.social', __('Social network icon size', 'floating-social-contact-buttons'), { min: 24, max: 70, unit: 'px' }));
    h += sect(__('Panel & text', 'floating-social-contact-buttons'), F.num('size.@.panel', __('Panel width', 'floating-social-contact-buttons'), { min: 200, max: 560, unit: 'px' }) +
      F.num('size.@.font', __('Base font size', 'floating-social-contact-buttons'), { min: 10, max: 22, unit: 'px' }) +
      F.num('size.@.title', __('Header title size', 'floating-social-contact-buttons'), { min: 12, max: 30, unit: 'px' }) +
      F.num('size.@.radius', __('Corner radius', 'floating-social-contact-buttons'), { min: 0, max: 40, unit: 'px' }) +
      F.num('size.@.gap', __('Space between items', 'floating-social-contact-buttons'), { min: 0, max: 30, unit: 'px' }) +
      F.num('style.border_width', __('Item border width', 'floating-social-contact-buttons'), { min: 0, max: 4, unit: 'px' }));
    return sect('', '<p class="fcp-note fcp-f--wide">' + ICON_SVG[S.device] + ' ' + sprintf(esc(/* translators: %s: device name in bold. */ __('Editing for %s. An empty field on tablet/mobile means the value of the larger device.', 'floating-social-contact-buttons')), '<b>' + esc(DEV_LABEL[S.device]) + '</b>') + '</p>') + h;
  };

  T.colors = function () {
    var presets = [
      ['#0b4a7a', '#22c55e', '#2f3e4c', '#f5c518'], ['#0f2a5f', '#0f2a5f', '#0f2a5f', '#ffffff'], ['#b8935f', '#0f5b36', '#1f1b17', '#c9a46b'],
      ['#075e54', '#25d366', '#075e54', '#ffffff'], ['#e11d48', '#e11d48', '#e11d48', '#ffffff'], ['#4f46e5', '#4f46e5', '#eef2ff', '#4f46e5'],
      ['#111827', '#111827', '#111827', '#ffffff'], ['#ef7f1a', '#ef7f1a', '#fff3e6', '#ef7f1a']
    ];
    var pal = '<div class="fcp-palettes fcp-f--wide">' + presets.map(function (p, i) {
      return '<button type="button" data-palette="' + i + '" title="' + esc(__('Apply palette', 'floating-social-contact-buttons')) + '">' + p.map(function (c) { return '<i style="background:' + c + '"></i>'; }).join('') + '</button>';
    }).join('') + '</div>';
    w._fcpPalettes = presets;
    var h = sect(__('Quick palette', 'floating-social-contact-buttons'), pal);
    h += sect(__('Main button', 'floating-social-contact-buttons'), F.color('colors.trigger_bg', __('Button / bar background', 'floating-social-contact-buttons')) + F.color('colors.trigger_color', __('Button icon color', 'floating-social-contact-buttons')) +
      F.color('colors.close_bg', __('Close button background', 'floating-social-contact-buttons')) + F.color('colors.close_color', __('Close icon color', 'floating-social-contact-buttons')) + F.color('colors.badge_bg', __('Notification badge color', 'floating-social-contact-buttons')));
    h += sect(__('Panel & header', 'floating-social-contact-buttons'), F.color('colors.panel_bg', __('Panel background', 'floating-social-contact-buttons')) + F.color('colors.header_bg', __('Header background', 'floating-social-contact-buttons')) +
      F.color('colors.header_bg2', __('Header gradient second color', 'floating-social-contact-buttons')) + F.color('colors.header_text', __('Header text', 'floating-social-contact-buttons')) + F.toggle('style.gradient', __('Gradient header', 'floating-social-contact-buttons')));
    h += sect(__('Items', 'floating-social-contact-buttons'), F.color('colors.item_bg', __('Item card background', 'floating-social-contact-buttons')) + F.color('colors.item_border', __('Border / divider', 'floating-social-contact-buttons')) +
      F.color('colors.item_title', __('Item title color', 'floating-social-contact-buttons')) + F.color('colors.item_value', __('Number / value color', 'floating-social-contact-buttons')) +
      F.color('colors.icon_bg', __('Icon box background', 'floating-social-contact-buttons')) + F.color('colors.icon_color', __('Icon color', 'floating-social-contact-buttons')) +
      F.toggle('style.network_colors', __('Brand color for each network', 'floating-social-contact-buttons'), { desc: __('Green WhatsApp icon, blue Telegram, orange Eitaa… (instead of one color)', 'floating-social-contact-buttons') }));
    h += sect(__('Social links, CTA button and labels', 'floating-social-contact-buttons'), F.color('colors.social_bg', __('Social icon background', 'floating-social-contact-buttons')) + F.color('colors.social_color', __('Social icon color', 'floating-social-contact-buttons')) +
      F.color('colors.cta_bg', __('CTA background', 'floating-social-contact-buttons')) + F.color('colors.cta_color', __('CTA text', 'floating-social-contact-buttons')) + F.color('colors.label_bg', __('Floating menu label background', 'floating-social-contact-buttons')) + F.color('colors.label_color', __('Floating menu label text', 'floating-social-contact-buttons')));
    h += sect(__('Global style', 'floating-social-contact-buttons'), F.select('style.shadow', __('Shadow', 'floating-social-contact-buttons'), { none: __('No shadow', 'floating-social-contact-buttons'), sm: __('Small', 'floating-social-contact-buttons'), md: __('Medium', 'floating-social-contact-buttons'), lg: __('Large', 'floating-social-contact-buttons'), xl: __('Extra large', 'floating-social-contact-buttons') }) +
      F.select('style.animation', __('Opening animation', 'floating-social-contact-buttons'), { slide: __('Slide', 'floating-social-contact-buttons'), scale: __('Zoom', 'floating-social-contact-buttons'), fade: __('Fade', 'floating-social-contact-buttons'), none: __('No animation', 'floating-social-contact-buttons') }) +
      F.toggle('style.glass', __('Glass effect', 'floating-social-contact-buttons')) + F.toggle('style.persian_digits', __('Show Persian digits', 'floating-social-contact-buttons'), { desc: __('۰۹۱۲… instead of 0912… (links are not changed)', 'floating-social-contact-buttons') }) +
      F.select('style.dir', __('Text direction', 'floating-social-contact-buttons'), { rtl: __('Right to left', 'floating-social-contact-buttons'), ltr: __('Left to right', 'floating-social-contact-buttons') }) +
      F.text('style.font', __('Font', 'floating-social-contact-buttons'), { ph: 'inherit', desc: 'inherit = ' + __('Theme/Elementor font, or a font name such as IRANYekanX, Vazirmatn', 'floating-social-contact-buttons') }));
    return h;
  };

  T.display = function () {
    var dsp = S.cur.display;
    var types = A.ruleTypes, rows = (dsp.rules || []).map(function (r, i) {
      var needs = ['post_type', 'ids', 'terms', 'url'].indexOf(r.type) > -1;
      return '<div class="fcp-rule"><select data-path="display.rules.' + i + '.mode"><option value="include"' + (r.mode === 'include' ? ' selected' : '') + '>' + esc(__('Show on', 'floating-social-contact-buttons')) + '</option><option value="exclude"' + (r.mode === 'exclude' ? ' selected' : '') + '>' + esc(__('Hide on', 'floating-social-contact-buttons')) + '</option></select>' +
        '<select data-path="display.rules.' + i + '.type" data-rerender>' + Object.keys(types).filter(function (k) { return A.woo || k.indexOf('woo_') !== 0; }).map(function (k) { return '<option value="' + k + '"' + (r.type === k ? ' selected' : '') + '>' + esc(types[k]) + '</option>'; }).join('') + '</select>' +
        (needs ? '<div class="fcp-rule__val"><input type="text" data-path="display.rules.' + i + '.value" value="' + esc(r.value) + '" placeholder="' + ({ post_type: 'page, product', ids: __('IDs: 12, 45', 'floating-social-contact-buttons'), terms: __('Category IDs: 7, 9', 'floating-social-contact-buttons'), url: '/product-category/' })[r.type] + '" dir="ltr">' +
          ((r.type === 'ids' || r.type === 'terms') ? '<input type="search" class="fcp-rule__search" data-rule-search="' + i + '" placeholder="' + esc(__('🔍 Search titles…', 'floating-social-contact-buttons')) + '"><div class="fcp-rule__res"></div>' : '') + '</div>' : '') +
        '<button type="button" class="fcp-mini fcp-mini--del" data-del-rule="' + i + '">×</button></div>';
    }).join('');
    var days = [[6, __('Saturday', 'floating-social-contact-buttons')], [0, __('Sunday', 'floating-social-contact-buttons')], [1, __('Monday', 'floating-social-contact-buttons')], [2, __('Tuesday', 'floating-social-contact-buttons')], [3, __('Wednesday', 'floating-social-contact-buttons')], [4, __('Thursday', 'floating-social-contact-buttons')], [5, __('Friday', 'floating-social-contact-buttons')]];
    var h = sect(__('Devices', 'floating-social-contact-buttons'), ['desktop', 'tablet', 'mobile'].map(function (k) { return F.toggle('display.' + k, __('Show on', 'floating-social-contact-buttons') + ' ' + DEV_LABEL[k]); }).join(''),
      { desc: __('Done with CSS, so it also works with page caching (WP Rocket, LiteSpeed…). The ranges can be changed in “Global settings”.', 'floating-social-contact-buttons') });
    h += sect(__('Pages', 'floating-social-contact-buttons'), '<div class="fcp-f--wide"><div class="fcp-rules">' + (rows || '<p class="fcp-empty">' + esc(__('No rules', 'floating-social-contact-buttons')) + ' = ' + esc(__('Show on the whole site', 'floating-social-contact-buttons')) + '</p>') + '</div><button type="button" class="button" data-add-rule>' + esc(__('+ Add rule', 'floating-social-contact-buttons')) + '</button></div>',
      { desc: __('“Hide on” rules take priority over “Show on”. Example: show on the whole site + hide on checkout.', 'floating-social-contact-buttons') });
    h += sect(__('Users & appearance timing', 'floating-social-contact-buttons'), F.select('display.users', __('Show for', 'floating-social-contact-buttons'), { all: __('Everyone', 'floating-social-contact-buttons'), guests: __('Guests only', 'floating-social-contact-buttons'), logged: __('Logged-in users only', 'floating-social-contact-buttons') }) +
      F.num('display.delay', __('Appear after', 'floating-social-contact-buttons'), { min: 0, max: 60, unit: __('seconds', 'floating-social-contact-buttons') }) + F.num('display.scroll', __('or after scrolling', 'floating-social-contact-buttons'), { min: 0, max: 100, unit: __('%', 'floating-social-contact-buttons') }) +
      F.toggle('display.hide_in_editor', __('Hide in the Elementor editor', 'floating-social-contact-buttons')));
    h += sect(__('Business hours', 'floating-social-contact-buttons'), F.toggle('display.sched_on', __('Only active during business hours', 'floating-social-contact-buttons'), { rerender: true, wide: true }) + (dsp.sched_on ?
      '<div class="fcp-f fcp-f--wide"><div class="fcp-f__head"><label>' + esc(__('Business days', 'floating-social-contact-buttons')) + '</label></div><div class="fcp-days">' + days.map(function (dd) {
        return '<label><input type="checkbox" data-day="' + dd[0] + '"' + ((dsp.sched_days || []).indexOf(dd[0]) > -1 ? ' checked' : '') + '><span>' + dd[1] + '</span></label>';
      }).join('') + '</div></div>' +
      '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('From', 'floating-social-contact-buttons')) + '</label></div><input type="time" data-path="display.sched_from" value="' + esc(dsp.sched_from) + '"></div>' +
      '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('To', 'floating-social-contact-buttons')) + '</label></div><input type="time" data-path="display.sched_to" value="' + esc(dsp.sched_to) + '"></div>' +
      F.select('display.sched_outside', __('Outside business hours', 'floating-social-contact-buttons'), { hide: __('Hide completely', 'floating-social-contact-buttons'), note: __('Show with an “outside business hours” message', 'floating-social-contact-buttons') }, { rerender: true }) +
      (dsp.sched_outside === 'note' ? F.textarea('display.sched_note', __('Outside business hours message', 'floating-social-contact-buttons'), { rows: 2 }) + F.toggle('', __('Preview the outside-hours state', 'floating-social-contact-buttons'), {}).replace('data-path=""', 'data-preview-offline' + (S.previewOffline ? ' checked' : '')) : '')
      : ''), { desc: __('Calculated with the WordPress time zone (Settings › General).', 'floating-social-contact-buttons') });
    return h;
  };

  T.advanced = function () {
    var id = S.cur.id;
    var sc = function (part) { return '[fscb id="' + id + '"' + (part ? ' part="' + part + '"' : '') + ']'; };
    var h = sect(__('Show in the footer or anywhere else (inline)', 'floating-social-contact-buttons'), '<div class="fcp-f--wide fcp-codes">' +
      [[__('Whole panel', 'floating-social-contact-buttons'), sc('')], [__('Contact items only', 'floating-social-contact-buttons'), sc('items')], [__('Social networks only (good for the footer)', 'floating-social-contact-buttons'), sc('socials')], [__('Social links – centered', 'floating-social-contact-buttons'), sc('socials').replace(']', ' align="center"]')]].map(function (r) {
        return '<div><span>' + r[0] + '</span><code dir="ltr">' + esc(r[1]) + '</code><button type="button" class="fcp-mini" data-copy="' + esc(r[1]) + '">' + esc(__('Duplicate', 'floating-social-contact-buttons')) + '</button></div>';
      }).join('') + '<p class="fcp-f__desc">' + esc(__('In Elementor, drag the “Contact / social buttons” widget into a header/footer (Theme Builder). In WoodMart, put the shortcode in an “HTML Block” or a footer column.', 'floating-social-contact-buttons')) + '</p></div>');
    h += sect(__('Tracking', 'floating-social-contact-buttons'), F.toggle('advanced.analytics', __('Send click events to Google Analytics / Tag Manager', 'floating-social-contact-buttons'), { desc: __('A dataLayer event named fcp_click and a gtag event named contact_click (with the network type and title).', 'floating-social-contact-buttons') }));
    h += sect(__('Custom CSS', 'floating-social-contact-buttons'), F.text('advanced.class', __('Additional CSS class', 'floating-social-contact-buttons'), { ltr: true }) + F.textarea('advanced.custom_css', __('CSS code', 'floating-social-contact-buttons'), { rows: 6, ltr: true, ph: '#fcp-' + id + ' .fcp-trig { … }' }));
    h += sect(__('Tools', 'floating-social-contact-buttons'), '<div class="fcp-f--wide fcp-tools"><button type="button" class="button" data-export>' + esc(__('⬇ Export this widget as JSON', 'floating-social-contact-buttons')) + '</button><button type="button" class="button" data-dup-instance>' + esc(__('⧉ Duplicate this widget', 'floating-social-contact-buttons')) + '</button><button type="button" class="button fcp-danger" data-delete-instance>' + esc(__('🗑 Delete widget', 'floating-social-contact-buttons')) + '</button></div>');
    return h;
  };

  /* ============================================================== views */

  function render() {
    if (S.view === 'list') return renderList();
    renderEditor();
  }

  function renderList() {
    var cards = S.list.map(function (inst) {
      return '<div class="fcp-icard"><div class="fcp-icard__prev" data-mini="' + inst.id + '"></div><div class="fcp-icard__body">' +
        '<div class="fcp-icard__top"><b>' + esc(inst.name) + '</b><label class="fcp-switch fcp-switch--sm" title="' + esc(__('Enable/disable', 'floating-social-contact-buttons')) + '"><input type="checkbox" data-quick-toggle="' + inst.id + '"' + (inst.enabled ? ' checked' : '') + '><span></span></label></div>' +
        '<small>' + esc((LAYOUTS[inst.layout] || [''])[0]) + ' · ' + sprintf(esc(/* translators: %d: number of items. */ _n('%d item', '%d items', (inst.items || []).length, 'floating-social-contact-buttons')), (inst.items || []).length) + ' · <code dir="ltr">' + esc(inst.id) + '</code></small>' +
        '<div class="fcp-icard__act"><button type="button" class="button button-primary" data-edit="' + inst.id + '">' + esc(__('Edit', 'floating-social-contact-buttons')) + '</button>' +
        '<button type="button" class="button" data-copy="[fscb id=&quot;' + inst.id + '&quot; part=&quot;socials&quot;]">' + esc(__('Copy shortcode', 'floating-social-contact-buttons')) + '</button></div></div></div>';
    }).join('');
    app.innerHTML = '<div class="fcp-top"><div class="fcp-brand"><span class="fcp-logo">' + svgFor('fas:phone-volume') + '</span><div><h1>' + esc(__('Floating contact buttons', 'floating-social-contact-buttons')) + '</h1><p>' + esc(__('Version', 'floating-social-contact-buttons')) + ' ' + A.version + '</p></div></div>' +
      '<div class="fcp-top__act"><button type="button" class="button" data-global>' + esc(__('⚙ Global settings', 'floating-social-contact-buttons')) + '</button><button type="button" class="button" data-import>' + esc(__('⬆ Import', 'floating-social-contact-buttons')) + '</button>' +
      '<button type="button" class="button button-primary button-hero" data-open-gallery="new">' + esc(__('+ Create a new contact button', 'floating-social-contact-buttons')) + '</button></div></div>' +
      (S.list.length ? '<div class="fcp-icards">' + cards + '</div>' :
        '<div class="fcp-welcome"><h2>' + esc(__('Create your first contact button 👋', 'floating-social-contact-buttons')) + '</h2><p>' + sprintf(esc(/* translators: %d: number of templates. */ __('Pick one of %d ready-made templates and customize everything: items, icons, colors, position and size for each device, and display conditions.', 'floating-social-contact-buttons')), TPL.length) + '</p><button type="button" class="button button-primary button-hero" data-open-gallery="new">' + esc(__('Choose a template', 'floating-social-contact-buttons')) + '</button></div>');
    S.list.forEach(function (inst) {
      ensureIcons(inst).then(function () { mountMini($('[data-mini="' + inst.id + '"]'), inst, 0.4); });
    });
  }

  function mountMini(box, inst, scale) {
    if (!box) return;
    box.innerHTML = '<div class="fcp-stage fcp-stage--mini" style="transform:scale(' + scale + ')"><div class="fcp-fake"><i></i><i></i><i></i><b></b><b></b></div></div>';
    var el = R.render(payload(inst), { mode: 'preview', device: 'desktop', open: true });
    if (el) box.firstChild.appendChild(el);
  }

  function renderEditor() {
    var c = S.cur;
    app.innerHTML = '<div class="fcp-ed">' +
      '<div class="fcp-ed__bar"><button type="button" class="button" data-back>' + esc(__('→ Back', 'floating-social-contact-buttons')) + '</button>' +
      '<input type="text" class="fcp-ed__name" data-path="name" value="' + esc(c.name) + '">' +
      '<label class="fcp-switch" title="' + esc(__('Enabled', 'floating-social-contact-buttons')) + '"><input type="checkbox" data-path="enabled" data-type="bool"' + (c.enabled ? ' checked' : '') + '><span></span></label><span class="fcp-ed__state">' + (c.enabled ? __('Enabled', 'floating-social-contact-buttons') : __('Disabled', 'floating-social-contact-buttons')) + '</span>' +
      '<span class="fcp-ed__sp"></span><span class="fcp-ed__dirty">' + (S.dirty ? __('Unsaved changes', 'floating-social-contact-buttons') : '') + '</span>' +
      '<button type="button" class="button button-primary button-large" data-save>' + (S.saving ? __('Saving…', 'floating-social-contact-buttons') : __('Save changes', 'floating-social-contact-buttons')) + '</button></div>' +
      '<div class="fcp-ed__main"><div class="fcp-ed__side"><nav class="fcp-tabs-nav">' + TABS.map(function (t) {
        return '<button type="button" data-tab="' + t[0] + '" class="' + (S.tab === t[0] ? 'is-on' : '') + '">' + t[1] + '</button>';
      }).join('') + '</nav><div class="fcp-ed__panel" id="fcp-panel"></div></div>' +
      '<div class="fcp-ed__prev"><div class="fcp-prevbar">' + devSwitch() +
      '<button type="button" class="button" data-preview-toggle>' + (S.previewOpen ? __('Closed view', 'floating-social-contact-buttons') : __('Open view', 'floating-social-contact-buttons')) + '</button></div>' +
      '<div class="fcp-prevwrap" id="fcp-prevwrap"></div><p class="fcp-f__desc fcp-prevnote">' + esc(__('Live preview — links are disabled here.', 'floating-social-contact-buttons')) + '</p></div></div></div>';
    renderPanel();
    renderPreview();
  }

  function renderPanel() {
    var p = $('#fcp-panel'); if (!p) return;
    var top = p.scrollTop;
    p.innerHTML = (T[S.tab] || T.layout)();
    p.scrollTop = top;
  }

  var renderPreview = function () {
    var wrap = $('#fcp-prevwrap'); if (!wrap || !S.cur) return;
    var dims = { desktop: [1100, 640], tablet: [800, 900], mobile: [390, 760] }[S.device];
    var avail = wrap.clientWidth || 600;
    var scale = Math.min(1, avail / dims[0]);
    wrap.style.height = Math.round(dims[1] * scale) + 'px';
    var inst = S.cur;
    ensureIcons(inst).then(function () {
      wrap.innerHTML = '<div class="fcp-stage fcp-stage--' + S.device + '" style="width:' + dims[0] + 'px;height:' + dims[1] + 'px;transform:scale(' + scale + ')"><div class="fcp-fake"><i></i><i></i><i></i><b></b><b></b><b></b></div></div>';
      var hidden = inst.display[S.device] === false;
      var el = R.render(payload(inst), { mode: 'preview', device: S.device, open: S.previewOpen, forceOffline: S.previewOffline });
      if (hidden) wrap.firstChild.insertAdjacentHTML('beforeend', '<div class="fcp-hiddenmsg">' + esc(sprintf(/* translators: %s: device name. */ __('This widget is hidden on %s', 'floating-social-contact-buttons'), DEV_LABEL[S.device])) + '</div>');
      if (el) {
        if (hidden) el.style.opacity = '.25';
        wrap.firstChild.appendChild(el);
        var ctl = R.bind(el, payload(inst), false);
        el.addEventListener('click', function (e) {
          var a = e.target.closest('a'); if (a) e.preventDefault();
          setTimeout(function () { S.previewOpen = el.classList.contains('is-open'); var b = $('[data-preview-toggle]'); if (b) b.textContent = S.previewOpen ? __('Closed view', 'floating-social-contact-buttons') : __('Open view', 'floating-social-contact-buttons'); }, 0);
        });
        if (inst.trigger.greet_show && !S.previewOpen) el.classList.add('greet-on');
      }
    });
  };
  var previewSoon = debounce(function () { renderPreview(); }, 120);

  function markDirty() {
    S.dirty = true;
    var el = $('.fcp-ed__dirty'); if (el) el.textContent = __('Unsaved changes', 'floating-social-contact-buttons');
  }

  /* ============================================================ gallery */

  function openGallery(mode) {
    var cat = 'all';
    var keep = mode === 'apply';
    var m = modal('<div class="fcp-gal__top"><h2>' + (mode === 'apply' ? __('Apply a ready-made template', 'floating-social-contact-buttons') : __('Choose a template', 'floating-social-contact-buttons')) + '</h2>' +
      '<div class="fcp-gal__cats">' + Object.keys(CATS).map(function (k) { return '<button type="button" data-cat="' + k + '" class="' + (k === 'all' ? 'is-on' : '') + '">' + CATS[k] + '</button>'; }).join('') + '</div>' +
      (mode === 'apply' ? '<label class="fcp-keep"><input type="checkbox" id="fcp-keep" checked> ' + esc(__('Keep my current items and texts', 'floating-social-contact-buttons')) + '</label>' : '') +
      (mode === 'new' ? '<button type="button" class="button" data-blank>' + esc(__('Start from scratch', 'floating-social-contact-buttons')) + '</button>' : '') + '</div><div class="fcp-gal" id="fcp-gal"></div>', 'fcp-modal--wide');
    Promise.all([loadPack('fas'), loadPack('fab'), loadPack('efa')]).then(function () {
      var draw = function () {
        var g = $('#fcp-gal', m); g.innerHTML = '';
        TPL.filter(function (t) { return cat === 'all' || t.cat === cat; }).forEach(function (t) {
          var card = d.createElement('button'); card.type = 'button'; card.className = 'fcp-gal__card'; card.setAttribute('data-tpl', t.key);
          card.innerHTML = '<div class="fcp-gal__prev"></div><span>' + esc(t.name) + '</span>';
          g.appendChild(card);
          var inst = deepMerge(clone(A.defaults), t.cfg); inst.id = 'tpl' + t.key.replace(/\W/g, '');
          mountMini(card.firstChild, inst, 0.36);
        });
      };
      draw();
      m.addEventListener('click', function (e) {
        var c = e.target.closest('[data-cat]');
        if (c) { cat = c.getAttribute('data-cat'); $$('[data-cat]', m).forEach(function (b) { b.classList.toggle('is-on', b === c); }); draw(); return; }
        var b = e.target.closest('[data-blank]');
        if (b) { closeModal(m); newInstance(null); return; }
        var t = e.target.closest('[data-tpl]');
        if (!t) return;
        var tpl = TPL.filter(function (x) { return x.key === t.getAttribute('data-tpl'); })[0];
        closeModal(m);
        if (mode === 'new') newInstance(tpl);
        else applyTemplate(tpl, $('#fcp-keep') ? $('#fcp-keep').checked : keep);
      });
    });
  }

  function freshIds(list) { return (list || []).map(function (it) { it.id = uid('i'); return it; }); }

  function newInstance(tpl) {
    var inst = clone(A.defaults);
    if (tpl) deepMerge(inst, clone(tpl.cfg));
    else inst.items = [Object.assign(clone(A.itemDef), { network: 'phone', label: __('Contact us', 'floating-social-contact-buttons'), value: '' })];
    inst.id = 'fcp' + Math.random().toString(36).slice(2, 8);
    inst.name = tpl ? tpl.name : __('New contact button', 'floating-social-contact-buttons');
    inst.items = freshIds(inst.items); inst.socials.items = freshIds(inst.socials.items);
    S.cur = inst; S.view = 'editor'; S.tab = 'items'; S.dirty = true; S.previewOpen = true; S.openItems = {};
    if (inst.items[0]) S.openItems['items:' + inst.items[0].id] = true;
    render();
    toast(__('Template selected — replace the numbers and IDs with your own details.', 'floating-social-contact-buttons'));
  }

  function applyTemplate(tpl, keep) {
    var old = S.cur, inst = deepMerge(clone(A.defaults), clone(tpl.cfg));
    inst.id = old.id; inst.name = old.name; inst.enabled = old.enabled; inst.display = old.display; inst.advanced = Object.assign({}, inst.advanced, { custom_css: old.advanced.custom_css, class: old.advanced.class });
    if (keep) {
      inst.items = old.items; inst.socials = Object.assign(inst.socials, { items: old.socials.items, title: old.socials.title });
      inst.header = Object.assign({}, inst.header, { title: old.header.title, subtitle: old.header.subtitle, agent: old.header.agent || inst.header.agent, message: old.header.message || inst.header.message, avatar: old.header.avatar });
      inst.cta.text = old.cta.text || inst.cta.text; inst.cta.link = old.cta.link; inst.cta.item = old.cta.item;
    } else { inst.items = freshIds(inst.items); inst.socials.items = freshIds(inst.socials.items); }
    S.cur = inst; markDirty(); render(); toast(sprintf(/* translators: %s: template name. */ __('Template “%s” applied', 'floating-social-contact-buttons'), tpl.name));
  }

  /* ============================================================ modals */

  function modal(html, cls) {
    var m = d.createElement('div'); m.className = 'fcp-modal ' + (cls || '');
    m.innerHTML = '<div class="fcp-modal__box" dir="' + (A.rtl ? 'rtl' : 'ltr') + '"><button type="button" class="fcp-modal__x" data-modal-close>×</button>' + html + '</div>';
    d.body.appendChild(m);
    m.addEventListener('click', function (e) { if (e.target === m || e.target.closest('[data-modal-close]')) closeModal(m); });
    setTimeout(function () { m.classList.add('is-in'); }, 10);
    return m;
  }
  function closeModal(m) { m.classList.remove('is-in'); setTimeout(function () { m.remove(); }, 200); }

  /* icon picker */
  var PICK_TABS = [['fas', __('Font Awesome Solid', 'floating-social-contact-buttons')], ['far', __('Font Awesome Regular', 'floating-social-contact-buttons')], ['fab', __('Brands', 'floating-social-contact-buttons')], ['efa', __('Iranian icons', 'floating-social-contact-buttons')], ['cus', __('My icons', 'floating-social-contact-buttons')]];
  PICK_TABS = PICK_TABS.filter(function (t) { return t[0] === 'cus' || (A.packs || []).indexOf(t[0]) > -1; });
  var SEARCH = null;
  function openIconPicker(path, cb) {
    var pack = 'fab', q = '', limit = 240;
    var curVal = get(S.cur, path) || '';
    if (curVal) { var cp = curVal.split(':')[0]; if (['fas', 'far', 'fab', 'efa', 'cus'].indexOf(cp) > -1) pack = cp; }
    var m = modal('<div class="fcp-pick"><div class="fcp-pick__top"><h2>' + esc(__('Choose icon', 'floating-social-contact-buttons')) + '</h2><input type="search" placeholder="' + esc(__('Search: phone, whatsapp, تلفن، ایتا…', 'floating-social-contact-buttons')) + '" class="fcp-pick__q" autofocus></div>' +
      '<div class="fcp-pick__tabs">' + PICK_TABS.map(function (t) { return '<button type="button" data-pack="' + t[0] + '" class="' + (t[0] === pack ? 'is-on' : '') + '">' + t[1] + '</button>'; }).join('') +
      '<button type="button" data-media-icon class="fcp-pick__media">' + esc(__('🖼 Image from the media library', 'floating-social-contact-buttons')) + '</button></div><div class="fcp-pick__grid"></div></div>', 'fcp-modal--wide');
    var grid = $('.fcp-pick__grid', m);
    var FA_SYN = { 'تلفن': 'phone', 'تماس': 'phone', 'ایمیل': 'envelope', 'نقشه': 'map', 'آدرس': 'location', 'پیام': 'comment', 'چت': 'comment', 'سبد': 'cart', 'خرید': 'cart', 'پشتیبانی': 'headset', 'ساعت': 'clock', 'کاربر': 'user', 'خانه': 'house', 'سوال': 'question', 'دانلود': 'download', 'ارسال': 'truck', 'تلگرام': 'telegram', 'واتساپ': 'whatsapp', 'اینستاگرام': 'instagram' };
    function draw() {
      if (pack === 'cus') return drawCustom();
      grid.innerHTML = '<p class="fcp-empty">' + esc(__('Loading…', 'floating-social-contact-buttons')) + '</p>';
      Promise.all([loadPack(pack), SEARCH ? SEARCH : (SEARCH = fetch(A.iconsUrl + 'search.json?v=' + A.version).then(function (r) { return r.json(); }).then(function (j) { SEARCH = j; return j; }))]).then(function () {
        var names = Object.keys(PACKS[pack]);
        var qq = q.trim().toLowerCase(); if (FA_SYN[qq]) qq = FA_SYN[qq];
        if (qq) names = names.filter(function (n) { var s = SEARCH[pack === 'efa' ? 'efa:' + n : n] || ''; return n.indexOf(qq) > -1 || s.indexOf(qq) > -1; });
        var total = names.length;
        grid.innerHTML = names.slice(0, limit).map(function (n) {
          var k = pack + ':' + n;
          return '<button type="button" data-icon="' + k + '" class="' + (k === curVal ? 'is-on' : '') + '" title="' + esc(n) + '">' + svgFor(k) + '<small>' + esc(n) + '</small></button>';
        }).join('') + (total > limit ? '<button type="button" class="fcp-pick__more" data-more>' + sprintf(esc(/* translators: %d: number of remaining icons. */ __('Show more (%d)', 'floating-social-contact-buttons')), total - limit) + '</button>' : '') + (!total ? '<p class="fcp-empty">' + esc(__('No icons found.', 'floating-social-contact-buttons')) + '</p>' : '');
      });
    }
    function drawCustom() {
      var lib = A.custom;
      grid.innerHTML = '<div class="fcp-cus"><div class="fcp-cus__add"><textarea dir="ltr" placeholder="' + esc(__('<svg …>…</svg> — paste the SVG code here', 'floating-social-contact-buttons')) + '" rows="3"></textarea>' +
        '<input type="text" placeholder="' + esc(__('Icon name', 'floating-social-contact-buttons')) + '"><label class="button">' + esc(__('Upload SVG file', 'floating-social-contact-buttons')) + '<input type="file" accept=".svg,image/svg+xml" hidden></label><button type="button" class="button button-primary" data-cus-save>' + esc(__('Add to library', 'floating-social-contact-buttons')) + '</button>' +
        '<p class="fcp-f__desc">' + esc(__('SVGs are sanitized (scripts and external references are removed). To follow the color settings, use fill', 'floating-social-contact-buttons')) + '="currentColor" ' + esc(__('in the SVG.', 'floating-social-contact-buttons')) + '</p></div>' +
        '<div class="fcp-pick__grid2">' + Object.keys(lib).map(function (id) {
          return '<div class="fcp-cus__it"><button type="button" data-icon="cus:' + id + '">' + svgFor('cus:' + id) + '<small>' + esc(lib[id].name) + '</small></button><button type="button" class="fcp-mini fcp-mini--del" data-cus-del="' + id + '">×</button></div>';
        }).join('') + '</div></div>';
      var file = $('input[type=file]', grid);
      file.addEventListener('change', function () {
        var f = file.files[0]; if (!f) return;
        var r = new FileReader(); r.onload = function () { $('textarea', grid).value = r.result; $('input[type=text]', grid).value = f.name.replace(/\.svg$/i, ''); }; r.readAsText(f);
      });
    }
    var qIn = $('.fcp-pick__q', m);
    qIn.addEventListener('input', debounce(function () { q = qIn.value; limit = 240; if (pack === 'cus') pack = 'fas'; syncTabs(); draw(); }, 200));
    function syncTabs() { $$('[data-pack]', m).forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-pack') === pack); }); }
    m.addEventListener('click', function (e) {
      var t;
      if ((t = e.target.closest('[data-pack]'))) { pack = t.getAttribute('data-pack'); limit = 240; syncTabs(); draw(); return; }
      if (e.target.closest('[data-more]')) { limit += 400; draw(); return; }
      if ((t = e.target.closest('[data-icon]'))) { cb(t.getAttribute('data-icon')); closeModal(m); return; }
      if (e.target.closest('[data-media-icon]')) {
        mediaPick(function (url) { cb('img:' + url); closeModal(m); }, ['image']); return;
      }
      if (e.target.closest('[data-cus-save]')) {
        var svg = $('textarea', grid).value, name = $('input[type=text]', grid).value || 'icon';
        ajax('icon_add', { svg: svg, name: name }).then(function (r) {
          if (!r.success) return toast(r.data && r.data.message || __('Error', 'floating-social-contact-buttons'), 'err');
          A.custom[r.data.id] = r.data.icon; drawCustom(); toast(__('Icon added', 'floating-social-contact-buttons'));
        }); return;
      }
      if ((t = e.target.closest('[data-cus-del]'))) {
        if (!confirm(__('Delete this icon from the library?', 'floating-social-contact-buttons'))) return;
        var id = t.getAttribute('data-cus-del');
        ajax('icon_delete', { id: id }).then(function () { delete A.custom[id]; drawCustom(); });
      }
    });
    draw();
  }

  function mediaPick(cb, types) {
    if (!w.wp || !w.wp.media) return toast(__('The media library is not available', 'floating-social-contact-buttons'), 'err');
    var frame = w.wp.media({ title: __('Choose image', 'floating-social-contact-buttons'), multiple: false, library: { type: types || ['image'] } });
    frame.on('select', function () { var a = frame.state().get('selection').first().toJSON(); cb(a.url); });
    frame.open();
  }

  function openGlobal() {
    var g = A.global;
    var m = modal('<h2>' + esc(__('Global settings', 'floating-social-contact-buttons')) + '</h2><div class="fcp-grid">' +
      '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('Default country code', 'floating-social-contact-buttons')) + '</label></div><input type="text" dir="ltr" id="g-cc" value="' + esc(g.country_code) + '"><p class="fcp-f__desc">' + esc(__('Turns 0912… into 98912… for WhatsApp and Viber.', 'floating-social-contact-buttons')) + '</p></div>' +
      '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('Maximum tablet width', 'floating-social-contact-buttons')) + '</label></div><input type="number" id="g-bt" value="' + esc(g.bp_tablet) + '"><p class="fcp-f__desc">' + esc(__('Elementor default: 1024', 'floating-social-contact-buttons')) + '</p></div>' +
      '<div class="fcp-f"><div class="fcp-f__head"><label>' + esc(__('Maximum mobile width', 'floating-social-contact-buttons')) + '</label></div><input type="number" id="g-bm" value="' + esc(g.bp_mobile) + '"><p class="fcp-f__desc">' + esc(__('Elementor default: 767', 'floating-social-contact-buttons')) + '</p></div>' +
      '</div><p><button type="button" class="button button-primary" id="g-save">' + esc(__('Save', 'floating-social-contact-buttons')) + '</button></p>');
    $('#g-save', m).addEventListener('click', function () {
      var ng = { country_code: $('#g-cc', m).value, bp_tablet: $('#g-bt', m).value, bp_mobile: $('#g-bm', m).value };
      ajax('global', { global: ng }).then(function (r) { if (r.success) { A.global = r.data.global; toast(__('Saved', 'floating-social-contact-buttons')); closeModal(m); } });
    });
  }

  function importJson() {
    var inp = d.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = function () {
      var f = inp.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () {
        try {
          var data = JSON.parse(r.result);
          var inst = deepMerge(clone(A.defaults), data.fcp || data);
          inst.id = 'fcp' + Math.random().toString(36).slice(2, 8);
          inst.name = (inst.name || __('Import', 'floating-social-contact-buttons')) + ' ' + __('(imported)', 'floating-social-contact-buttons');
          S.cur = inst; S.view = 'editor'; S.dirty = true; S.tab = 'layout'; render();
          toast(__('Imported — save to keep it.', 'floating-social-contact-buttons'));
        } catch (e) { toast(__('The JSON file is not valid', 'floating-social-contact-buttons'), 'err'); }
      };
      r.readAsText(f);
    };
    inp.click();
  }

  /* ============================================================== save */

  function save() {
    if (S.saving) return;
    S.saving = true; var btn = $('[data-save]'); if (btn) btn.textContent = __('Saving…', 'floating-social-contact-buttons');
    ajax('save', { instance: S.cur }).then(function (r) {
      S.saving = false;
      if (!r.success) { toast((r.data && r.data.message) || __('Not saved', 'floating-social-contact-buttons'), 'err'); if (btn) btn.textContent = __('Save changes', 'floating-social-contact-buttons'); return; }
      var saved = r.data.instance, found = false;
      S.list = S.list.map(function (i) { if (i.id === saved.id) { found = true; return saved; } return i; });
      if (!found) S.list.push(saved);
      // keep the editor's object (and UI state) but adopt server-sanitised values
      S.cur = saved; S.dirty = false;
      renderEditor();
      toast(__('Saved ✓ (page cache cleared)', 'floating-social-contact-buttons'));
    }).catch(function () { S.saving = false; toast(__('Could not connect to the server', 'floating-social-contact-buttons'), 'err'); if (btn) btn.textContent = __('Save changes', 'floating-social-contact-buttons'); });
  }

  /* ============================================================ events */

  function readInput(el) {
    var t = el.getAttribute('data-type'), path = rp(el.getAttribute('data-path'));
    var v;
    if (t === 'bool') v = el.checked;
    else if (t === 'num') v = el.value === '' ? (/\.(tablet|mobile)\./.test(path) ? '' : 0) : +el.value;
    else v = el.value;
    if (path === 'display.rules') return;
    set(S.cur, path, v);
    return path;
  }

  app.addEventListener('input', function (e) {
    var el = e.target;
    if (el.hasAttribute('data-color-for')) {
      var p = el.getAttribute('data-color-for'); set(S.cur, rp(p), el.value);
      var txt = el.closest('.fcp-color').querySelector('input[type=text]'); txt.value = el.value;
      el.parentNode.style.background = el.value; markDirty(); previewSoon(); return;
    }
    if (el.hasAttribute('data-rule-search')) { ruleSearch(el); return; }
    if (!el.hasAttribute('data-path') || el.type === 'checkbox' || el.tagName === 'SELECT') return;
    readInput(el); markDirty(); previewSoon();
    // sync range <-> number
    if (el.type === 'range' || el.type === 'number') {
      var twin = el.parentNode.querySelector(el.type === 'range' ? 'input[type=number]' : 'input[type=range]');
      if (twin) twin.value = el.value;
    }
    if (el.closest('.fcp-color')) el.closest('.fcp-color').querySelector('.fcp-color__sw').style.background = el.value || 'transparent';
    if (el.getAttribute('data-path') === 'name') { /* nothing */ }
    var item = el.closest('.fcp-rep__item');
    if (item && /\.(label|value)$/.test(el.getAttribute('data-path'))) {
      var arr = get(S.cur, item.getAttribute('data-rep'))[+item.getAttribute('data-idx')];
      var net = A.networks[arr.network] || {};
      item.querySelector('.fcp-rep__title b').textContent = arr.label || net.label;
      item.querySelector('.fcp-rep__title small').textContent = arr.value || '—';
    }
  });

  app.addEventListener('change', function (e) {
    var el = e.target;
    if (el.hasAttribute('data-preview-offline')) { S.previewOffline = el.checked; renderPreview(); return; }
    if (el.hasAttribute('data-quick-toggle')) {
      var inst = S.list.filter(function (i) { return i.id === el.getAttribute('data-quick-toggle'); })[0];
      inst.enabled = el.checked;
      ajax('save', { instance: inst }).then(function (r) { toast(r.success ? (inst.enabled ? __('Enabled', 'floating-social-contact-buttons') : __('Disabled', 'floating-social-contact-buttons')) : __('Error', 'floating-social-contact-buttons'), r.success ? 'ok' : 'err'); });
      return;
    }
    if (el.hasAttribute('data-add-net')) {
      var grp = el.getAttribute('data-add-net'), net = el.value; if (!net) return;
      var it = Object.assign(clone(A.itemDef), { id: uid('i'), network: net });
      var list = get(S.cur, grp); list.push(it);
      S.openItems[grp + ':' + it.id] = true;
      markDirty(); renderPanel(); renderPreview(); return;
    }
    if (el.hasAttribute('data-day')) {
      var days = $$('[data-day]').filter(function (c) { return c.checked; }).map(function (c) { return +c.getAttribute('data-day'); });
      S.cur.display.sched_days = days; markDirty(); renderPreview(); return;
    }
    if (!el.hasAttribute('data-path')) return;
    if (el.type === 'checkbox' || el.tagName === 'SELECT' || el.type === 'time') {
      var path = readInput(el);
      if (path === 'enabled') { var st = $('.fcp-ed__state'); if (st) st.textContent = el.checked ? __('Enabled', 'floating-social-contact-buttons') : __('Disabled', 'floating-social-contact-buttons'); }
      if (/^(items|socials\.items)\.\d+\.network$/.test(path)) {
        var obj = get(S.cur, path.replace(/\.network$/, '')); obj.icon = ''; // network default icon
      }
      markDirty();
      if (el.hasAttribute('data-rerender') || el.hasAttribute('data-rerender-item') || path === 'layout') renderPanel();
      renderPreview();
    }
  });

  app.addEventListener('click', function (e) {
    var t = e.target, b;
    if ((b = t.closest('[data-edit]'))) {
      var src = S.list.filter(function (i) { return i.id === b.getAttribute('data-edit'); })[0];
      S.cur = clone(src); S.view = 'editor'; S.tab = 'layout'; S.dirty = false; S.openItems = {}; render(); return;
    }
    if (t.closest('[data-back]')) {
      if (S.dirty && !confirm(__('You have unsaved changes. Leave anyway?', 'floating-social-contact-buttons'))) return;
      S.view = 'list'; S.cur = null; S.dirty = false; render(); return;
    }
    if (t.closest('[data-save]')) return save();
    if ((b = t.closest('[data-open-gallery]'))) return openGallery(b.getAttribute('data-open-gallery'));
    if (t.closest('[data-global]')) return openGlobal();
    if (t.closest('[data-import]')) return importJson();
    if ((b = t.closest('[data-tab]'))) { S.tab = b.getAttribute('data-tab'); $$('[data-tab]').forEach(function (x) { x.classList.toggle('is-on', x === b); }); $('#fcp-panel').scrollTop = 0; renderPanel(); return; }
    if ((b = t.closest('[data-device]'))) { S.device = b.getAttribute('data-device'); $$('[data-device]').forEach(function (x) { x.classList.toggle('is-on', x === b); }); renderPanel(); renderPreview(); return; }
    if (t.closest('[data-preview-toggle]')) { S.previewOpen = !S.previewOpen; t.closest('[data-preview-toggle]').textContent = S.previewOpen ? __('Closed view', 'floating-social-contact-buttons') : __('Open view', 'floating-social-contact-buttons'); renderPreview(); return; }
    if ((b = t.closest('[data-choice]'))) {
      set(S.cur, rp(b.getAttribute('data-choice')), b.getAttribute('data-value')); markDirty();
      if (b.getAttribute('data-choice') === 'layout' || b.hasAttribute('data-rerender') || b.closest('.fcp-place')) renderPanel();
      else $$('[data-choice="' + b.getAttribute('data-choice') + '"]').forEach(function (x) { x.classList.toggle('is-on', x === b); });
      renderPreview(); return;
    }
    if ((b = t.closest('[data-clear]'))) { set(S.cur, rp(b.getAttribute('data-clear')), ''); markDirty(); renderPanel(); renderPreview(); return; }
    if ((b = t.closest('[data-pick-icon]'))) {
      var path = rp(b.getAttribute('data-pick-icon'));
      openIconPicker(path, function (key) { set(S.cur, path, key); markDirty(); renderPanel(); renderPreview(); });
      return;
    }
    if ((b = t.closest('[data-media]'))) {
      var mp = rp(b.getAttribute('data-media'));
      mediaPick(function (url) { set(S.cur, mp, url); markDirty(); renderPanel(); renderPreview(); }); return;
    }
    if ((b = t.closest('[data-toggle-item]'))) {
      if (t.closest('button,label,input')) return;
      var k = b.getAttribute('data-toggle-item'); S.openItems[k] = !S.openItems[k]; renderPanel(); return;
    }
    if ((b = t.closest('[data-del]'))) {
      if (!confirm(__('Delete this item?', 'floating-social-contact-buttons'))) return;
      get(S.cur, b.getAttribute('data-del')).splice(+b.getAttribute('data-idx'), 1); markDirty(); renderPanel(); renderPreview(); return;
    }
    if ((b = t.closest('[data-dup]'))) {
      var arr = get(S.cur, b.getAttribute('data-dup')), i = +b.getAttribute('data-idx');
      var cp = clone(arr[i]); cp.id = uid('i'); arr.splice(i + 1, 0, cp); markDirty(); renderPanel(); renderPreview(); return;
    }
    if (t.closest('[data-add-rule]')) { S.cur.display.rules.push({ mode: 'include', type: 'all', value: '' }); markDirty(); renderPanel(); return; }
    if ((b = t.closest('[data-del-rule]'))) { S.cur.display.rules.splice(+b.getAttribute('data-del-rule'), 1); markDirty(); renderPanel(); return; }
    if ((b = t.closest('[data-rule-pick]'))) {
      var ri = +b.getAttribute('data-rule-pick'), rule = S.cur.display.rules[ri];
      var ids = String(rule.value || '').split(/[\s,]+/).filter(Boolean);
      if (ids.indexOf(b.getAttribute('data-id')) < 0) ids.push(b.getAttribute('data-id'));
      rule.value = ids.join(', '); markDirty(); renderPanel(); return;
    }
    if ((b = t.closest('[data-palette]'))) {
      var p = w._fcpPalettes[+b.getAttribute('data-palette')];
      Object.assign(S.cur.colors, { header_bg: p[0], header_bg2: p[0], trigger_bg: p[1], close_bg: p[0], icon_bg: p[2], icon_color: p[3], social_bg: p[2], social_color: p[3], item_value: p[0], cta_bg: p[1] });
      markDirty(); renderPanel(); renderPreview(); return;
    }
    if ((b = t.closest('[data-copy]'))) {
      var txt = b.getAttribute('data-copy');
      (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { toast(sprintf(/* translators: %s: copied text. */ __('Copied: %s', 'floating-social-contact-buttons'), txt)); }, function () { prompt(__('Copy this:', 'floating-social-contact-buttons'), txt); });
      return;
    }
    if (t.closest('[data-export]')) {
      var blob = new Blob([JSON.stringify({ fcp: S.cur, version: A.version }, null, 2)], { type: 'application/json' });
      var a = d.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'fcp-' + S.cur.id + '.json'; a.click(); return;
    }
    if (t.closest('[data-dup-instance]')) {
      var c = clone(S.cur); c.id = 'fcp' + Math.random().toString(36).slice(2, 8); c.name += ' ' + __('(copy)', 'floating-social-contact-buttons');
      S.cur = c; S.dirty = true; render(); toast(__('Copy created — save to keep it.', 'floating-social-contact-buttons')); return;
    }
    if (t.closest('[data-delete-instance]')) {
      if (!confirm(__('Delete this widget permanently?', 'floating-social-contact-buttons'))) return;
      var id = S.cur.id;
      ajax('delete', { id: id }).then(function () { S.list = S.list.filter(function (i) { return i.id !== id; }); S.view = 'list'; S.cur = null; S.dirty = false; render(); toast(__('Deleted', 'floating-social-contact-buttons')); });
    }
  });

  var ruleSearch = debounce(function (el) {
    var q = el.value.trim(), box = el.parentNode.querySelector('.fcp-rule__res');
    if (q.length < 2) { box.innerHTML = ''; return; }
    var ri = el.getAttribute('data-rule-search'), type = S.cur.display.rules[+ri].type;
    ajax('search_posts', { q: q }).then(function (r) {
      var res = (r.data || []).filter(function (x) { return type === 'terms' ? x.type.indexOf('term:') === 0 : x.type.indexOf('term:') !== 0; });
      box.innerHTML = res.length ? res.map(function (x) { return '<button type="button" data-rule-pick="' + ri + '" data-id="' + x.id + '">' + esc(x.title) + ' <small>(' + esc(x.type.replace('term:', '')) + ' #' + x.id + ')</small></button>'; }).join('') : '<small>' + esc(__('No results', 'floating-social-contact-buttons')) + '</small>';
    });
  }, 300);

  // drag & drop reorder of repeater items
  var drag = null;
  app.addEventListener('mousedown', function (e) {
    var h = e.target.closest && e.target.closest('.fcp-rep__drag');
    if (h) h.closest('.fcp-rep__item').setAttribute('draggable', 'true');
  });
  app.addEventListener('mouseup', function () { $$('.fcp-rep__item[draggable=true]').forEach(function (n) { if (n !== drag) n.setAttribute('draggable', 'false'); }); });
  app.addEventListener('dragstart', function (e) {
    var it = e.target.closest && e.target.closest('.fcp-rep__item');
    if (!it || !e.target.closest('.fcp-rep__item')) return;
    drag = it; it.classList.add('is-drag'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', ''); } catch (x) { /* */ }
  });
  app.addEventListener('dragover', function (e) {
    if (!drag) return;
    var over = e.target.closest && e.target.closest('.fcp-rep__item');
    if (!over || over === drag || over.getAttribute('data-rep') !== drag.getAttribute('data-rep')) return;
    e.preventDefault();
    var r = over.getBoundingClientRect();
    over.parentNode.insertBefore(drag, (e.clientY - r.top) > r.height / 2 ? over.nextSibling : over);
  });
  app.addEventListener('dragend', function () {
    if (!drag) return;
    var grp = drag.getAttribute('data-rep'), list = get(S.cur, grp);
    var order = $$('.fcp-rep__item', drag.parentNode).map(function (n) { return list[+n.getAttribute('data-idx')]; });
    set(S.cur, grp, order); drag = null; markDirty(); renderPanel(); renderPreview();
  });

  w.addEventListener('resize', debounce(function () { if (S.view === 'editor') renderPreview(); }, 150));
  w.addEventListener('beforeunload', function (e) { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });
  d.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 's' && S.view === 'editor') { e.preventDefault(); save(); } });

  Promise.all([loadPack('fas'), loadPack('fab')]).then(render, render);
})(window, document);
