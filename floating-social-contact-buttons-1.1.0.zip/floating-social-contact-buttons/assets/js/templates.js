/* Floating Social & Contact Buttons – ready-made templates (partial instance configs). */
(function (w) {
  'use strict';

  var __ = w.wp.i18n.__;

  var n = 0;
  function it(network, label, value, extra) {
    var o = { id: 't' + (++n), enabled: true, network: network, label: label, sub: '', value: value || '', message: '', icon: '', color: '', icon_color: '', bg: '', new_tab: true };
    for (var k in extra || {}) o[k] = extra[k];
    return o;
  }
  var PH = '09121234567', TEL = '021-22010230';
  var SOC = function () { return [it('instagram', __('Instagram', 'floating-social-contact-buttons'), 'yourpage'), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'yourid'), it('bale', __('Bale', 'floating-social-contact-buttons'), 'yourid')]; };
  var SIZE = function (o) {
    var s = { desktop: { trigger: 60, icon: 26, panel: 340, font: 14, item_icon: 44, radius: 18, gap: 10, social: 38, title: 17 }, tablet: {}, mobile: { trigger: 56, icon: 24, panel: 310, item_icon: 40, title: 16 } };
    for (var k in o || {}) s.desktop[k] = o[k];
    return s;
  };
  var POS = function (place, x, y, mplace) {
    return { desktop: { place: place, x: x == null ? 24 : x, y: y == null ? 24 : y }, tablet: { place: '', x: '', y: '' }, mobile: { place: mplace || '', x: x == null ? 16 : Math.min(x, 16), y: y == null ? 16 : Math.min(y, 16) } };
  };

  var T = [];
  function add(key, name, cat, cfg) { cfg.template = key; T.push({ key: key, name: name, cat: cat, cfg: cfg }); }

  /* ---------- Persian contact-card panels (like the reference screenshots) ---------- */
  add('cards-navy', __('Advice cards – navy & gold', 'floating-social-contact-buttons'), 'panel', {
    layout: 'panel',
    header: { show: true, title: __('Need expert advice?', 'floating-social-contact-buttons'), subtitle: __('Contact our sales consultants', 'floating-social-contact-buttons') },
    items: [it('support', __('Sales advice', 'floating-social-contact-buttons'), PH, { icon: 'fas:headset' }), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('bale', __('Message on Bale', 'floating-social-contact-buttons'), PH)],
    socials: { show: true, title: __('Social networks:', 'floating-social-contact-buttons'), items: [it('instagram', __('Instagram', 'floating-social-contact-buttons'), 'page'), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('bale', __('Bale', 'floating-social-contact-buttons'), 'id')], shape: 'rounded' },
    opts: { item_style: 'card', close_style: 'outside', show_value: true },
    trigger: { icon: 'fas:phone-volume', shape: 'rounded', pulse: true, animate: 'shake' },
    colors: { trigger_bg: '#22c55e', trigger_color: '#ffffff', close_bg: '#0b3d6b', close_color: '#fff', panel_bg: '#ffffff', header_bg: '#0b4a7a', header_bg2: '#0b3d6b', header_text: '#ffffff', item_bg: '#f4f7fb', item_border: '#e2e8f0', item_title: '#475569', item_value: '#0b4a7a', icon_bg: '#2f3e4c', icon_color: '#f5c518', social_bg: '#2f3e4c', social_color: '#f5c518' },
    style: { network_colors: false, gradient: true, shadow: 'lg', animation: 'slide' }, size: SIZE()
  });

  add('cards-gold-dark', __('Dark luxury – gold', 'floating-social-contact-buttons'), 'panel', {
    layout: 'panel',
    header: { show: true, title: __('Need expert advice?', 'floating-social-contact-buttons'), subtitle: __('Contact the sales team', 'floating-social-contact-buttons') },
    items: [it('phone', __('Contact the advice team', 'floating-social-contact-buttons'), TEL, { icon: 'fas:phone' }), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH, { bg: '#1d3a24', icon_color: '#ffffff' })],
    socials: { show: false, items: [] },
    opts: { item_style: 'minimal', close_style: 'outside', show_value: true },
    trigger: { icon: 'fas:phone', shape: 'circle', pulse: true, animate: 'rotate' },
    colors: { trigger_bg: '#0f5b36', trigger_color: '#ffffff', close_bg: '#b8935f', close_color: '#fff', panel_bg: '#141210', header_bg: '#b8935f', header_bg2: '#a07d4c', header_text: '#ffffff', item_bg: '#1f1b17', item_border: '#2a241d', item_title: '#c9a46b', item_value: '#ffffff', icon_bg: 'transparent', icon_color: '#c9a46b' },
    style: { gradient: false, shadow: 'xl', border_width: 0 }, size: SIZE({ radius: 4 })
  });

  add('cards-royal', __('Color cards – royal blue', 'floating-social-contact-buttons'), 'panel', {
    layout: 'panel',
    header: { show: true, title: __('Need expert advice?', 'floating-social-contact-buttons'), subtitle: __('Contact our sales consultants', 'floating-social-contact-buttons') },
    items: [it('support', __('Sales advice', 'floating-social-contact-buttons'), '021-26306267', { color: '#c9a35b' }), it('phone', __('Sales office phone', 'floating-social-contact-buttons'), '021-26306319', { color: '#0f2a5f' }), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), '0912-215-3229', { color: '#22a565' }), it('telegram', __('Telegram', 'floating-social-contact-buttons'), '09122153229', { color: '#229ed9', icon: 'fas:paper-plane' })],
    socials: { show: true, title: __('Social networks:', 'floating-social-contact-buttons'), items: [it('instagram', __('Instagram', 'floating-social-contact-buttons'), 'page'), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id', { icon: 'fas:paper-plane' }), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH)], shape: 'rounded' },
    opts: { item_style: 'card', close_style: 'trigger', show_value: true },
    trigger: { icon: 'fas:headset', shape: 'rounded', pulse: false, animate: 'rotate' },
    colors: { trigger_bg: '#0f2a5f', trigger_color: '#ffffff', panel_bg: '#ffffff', header_bg: '#0f2a5f', header_bg2: '#2563eb', header_text: '#ffffff', item_bg: '#f3f6fb', item_border: '#e5eaf3', item_title: '#64748b', item_value: '#0f2a5f', icon_bg: '#0f2a5f', icon_color: '#ffffff', social_bg: '#0f2a5f', social_color: '#ffffff' },
    style: { gradient: true, shadow: 'xl' }, size: SIZE({ radius: 22 })
  });

  add('cards-iran', __('Iranian messengers', 'floating-social-contact-buttons'), 'panel', {
    layout: 'panel',
    header: { show: true, title: __('Through Iranian messengers', 'floating-social-contact-buttons'), subtitle: __('Fast replies during business hours', 'floating-social-contact-buttons'), icon: 'fas:comments' },
    items: [it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), '@yourid', { sub: __('Replies within 10 minutes', 'floating-social-contact-buttons') }), it('bale', __('Bale', 'floating-social-contact-buttons'), '@yourid', { sub: __('Send files and invoices', 'floating-social-contact-buttons') }), it('rubika', __('Rubika', 'floating-social-contact-buttons'), '@yourid', { sub: __('Discounts channel', 'floating-social-contact-buttons') }), it('soroush', __('Soroush Plus', 'floating-social-contact-buttons'), '@yourid', { sub: __('Support', 'floating-social-contact-buttons') })],
    socials: { show: false, items: [] },
    opts: { item_style: 'tinted', close_style: 'inside', show_value: false },
    trigger: { icon: 'fas:comment-dots', shape: 'circle', pulse: true, badge_show: true, badge_text: '1' },
    colors: { trigger_bg: '#ef7f1a', trigger_color: '#fff', panel_bg: '#ffffff', header_bg: '#ef7f1a', header_bg2: '#f59e0b', header_text: '#fff', item_bg: '#f8fafc', item_border: '#eef2f7', item_title: '#1f2937', item_value: '#ef7f1a' },
    style: { network_colors: true, gradient: true }, size: SIZE()
  });

  add('cards-grid', __('Grid tiles', 'floating-social-contact-buttons'), 'panel', {
    layout: 'panel',
    header: { show: true, title: __('Ways to contact us', 'floating-social-contact-buttons'), subtitle: __('Whichever suits you', 'floating-social-contact-buttons') },
    items: [it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id'), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'id'), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir'), it('neshan', __('Directions', 'floating-social-contact-buttons'), 'https://nshn.ir/')],
    socials: { show: false, items: [] },
    opts: { item_style: 'grid', columns: 3, close_style: 'inside', show_value: false },
    trigger: { icon: 'fas:comments', shape: 'circle', pulse: true },
    colors: { trigger_bg: '#4f46e5', trigger_color: '#fff', header_bg: '#4f46e5', header_bg2: '#7c3aed', header_text: '#fff', item_bg: '#f5f6ff', item_border: '#eceefe', item_title: '#312e81' },
    style: { network_colors: true }, size: SIZE({ panel: 360 })
  });

  /* ---------- link lists ---------- */
  add('list-help', __('Help list + button', 'floating-social-contact-buttons'), 'list', {
    layout: 'panel',
    header: { show: true, title: __('Need help?', 'floating-social-contact-buttons'), subtitle: '' },
    items: [it('phone', __('Phone call', 'floating-social-contact-buttons'), TEL), it('whatsapp', __('Start chat', 'floating-social-contact-buttons'), PH), it('faq', __('FAQ', 'floating-social-contact-buttons'), '/faq'), it('neshan', __('Directions', 'floating-social-contact-buttons'), 'https://nshn.ir/')],
    cta: { show: true, text: __('Send a message', 'floating-social-contact-buttons'), icon: '', link: '', item: '' },
    socials: { show: false, items: [] },
    opts: { item_style: 'row', close_style: 'inside', show_value: false },
    trigger: { icon: 'fas:circle-info', shape: 'circle', pulse: false },
    colors: { trigger_bg: '#ffffff', trigger_color: '#0f766e', panel_bg: '#ffffff', header_bg: '#ffffff', header_bg2: '#ffffff', header_text: '#0f766e', item_title: '#1f2937', item_value: '#0f766e', item_border: '#e5e7eb', cta_bg: '#0f766e', cta_color: '#fff' },
    style: { gradient: false }, size: SIZE({ panel: 280, trigger: 48, icon: 20, title: 16 })
  });

  add('list-tinted-orange', __('Color list – orange', 'floating-social-contact-buttons'), 'list', {
    layout: 'panel',
    header: { show: true, title: __('Online support', 'floating-social-contact-buttons'), subtitle: __('How would you like to get help?', 'floating-social-contact-buttons') },
    items: [it('whatsapp', __('Message on WhatsApp', 'floating-social-contact-buttons'), PH, { sub: __('Quick reply', 'floating-social-contact-buttons') }), it('website', __('Customer panel', 'floating-social-contact-buttons'), '/my-account', { sub: __('Orders and invoices', 'floating-social-contact-buttons') }), it('phone', __('Billing questions', 'floating-social-contact-buttons'), TEL, { sub: __('Accounting department', 'floating-social-contact-buttons') }), it('email', __('Tips and tutorials', 'floating-social-contact-buttons'), 'info@site.ir', { sub: __('Newsletter', 'floating-social-contact-buttons') })],
    socials: { show: false, items: [] },
    opts: { item_style: 'tinted', close_style: 'trigger', show_value: false },
    trigger: { icon: 'fas:headset', shape: 'circle', pulse: false },
    colors: { trigger_bg: '#ffffff', trigger_color: '#1f2937', header_bg: '#ff8a65', header_bg2: '#ffa38a', header_text: '#fff', item_title: '#3f1d0e', item_value: '#ff6f43', icon_bg: '#ff8a65' },
    style: { network_colors: false }, size: SIZE({ panel: 290, trigger: 44, icon: 18, title: 15 })
  });

  add('list-tinted-navy', __('Color list – navy & yellow', 'floating-social-contact-buttons'), 'list', {
    layout: 'panel',
    header: { show: true, title: __('Student resources', 'floating-social-contact-buttons'), subtitle: __('Everything you need', 'floating-social-contact-buttons') },
    items: [it('whatsapp', __('Course questions', 'floating-social-contact-buttons'), PH, { sub: __('Education advisor', 'floating-social-contact-buttons') }), it('website', __('Your courses', 'floating-social-contact-buttons'), '/courses', { sub: __('Log in', 'floating-social-contact-buttons') }), it('phone', __('Sign up', 'floating-social-contact-buttons'), TEL, { sub: __('Admissions office', 'floating-social-contact-buttons') }), it('google_maps', __('Campus map', 'floating-social-contact-buttons'), 'Tehran', { sub: __('Address and directions', 'floating-social-contact-buttons') })],
    socials: { show: false, items: [] },
    opts: { item_style: 'tinted', close_style: 'trigger', show_value: false },
    trigger: { icon: 'fas:graduation-cap', shape: 'circle' },
    colors: { trigger_bg: '#ffffff', trigger_color: '#1e3a5f', header_bg: '#1e3a5f', header_bg2: '#1e3a5f', header_text: '#fff', item_title: '#1e293b', icon_bg: '#1e3a5f', icon_color: '#facc15' },
    style: { gradient: false }, size: SIZE({ panel: 280, trigger: 44, icon: 18, title: 15 })
  });

  add('list-dark-red', __('Dark list – red', 'floating-social-contact-buttons'), 'list', {
    layout: 'panel',
    header: { show: true, title: __('Urgent help', 'floating-social-contact-buttons'), subtitle: '' },
    items: [it('phone', __('Contact us', 'floating-social-contact-buttons'), TEL), it('faq', __('Ordering guide', 'floating-social-contact-buttons'), '/guide'), it('tracking', __('Order tracking', 'floating-social-contact-buttons'), '/track'), it('neshan', __('Store address', 'floating-social-contact-buttons'), 'https://nshn.ir/')],
    cta: { show: true, text: __('Shop now', 'floating-social-contact-buttons'), icon: 'fas:cart-shopping', link: '/shop' },
    socials: { show: false, items: [] },
    opts: { item_style: 'row', close_style: 'inside', show_value: false },
    trigger: { icon: 'fas:circle-question', shape: 'circle' },
    colors: { trigger_bg: '#262626', trigger_color: '#fff', panel_bg: '#111111', header_bg: '#111111', header_bg2: '#111111', header_text: '#f43f5e', item_border: '#262626', item_title: '#e5e5e5', item_value: '#ffffff', item_bg: '#1c1c1c', cta_bg: '#f43f5e', cta_color: '#fff' },
    style: { gradient: false }, size: SIZE({ panel: 250, trigger: 44, icon: 18, title: 15 })
  });

  /* ---------- chat bubbles ---------- */
  add('chat-whatsapp', __('WhatsApp chat with an advisor', 'floating-social-contact-buttons'), 'chat', {
    layout: 'chat',
    header: { show: true, agent: __('Sarah Miller', 'floating-social-contact-buttons'), role: __('Sales consultant', 'floating-social-contact-buttons'), message: __('Hello 👋\nHow can I help you?', 'floating-social-contact-buttons'), time: '10:30', online: true },
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH, { message: __('Hi, I am writing from your website', 'floating-social-contact-buttons') })],
    cta: { show: true, text: __('Start chatting on WhatsApp', 'floating-social-contact-buttons'), icon: 'fab:whatsapp', item: '' },
    opts: { chat_mode: 'button', close_style: 'inside' },
    trigger: { icon: 'fab:whatsapp', shape: 'circle', pulse: true, badge_show: true, badge_text: '1', greet_show: true },
    colors: { trigger_bg: '#25d366', trigger_color: '#fff', header_bg: '#075e54', header_bg2: '#128c7e', header_text: '#fff', cta_bg: '#25d366', cta_color: '#fff' },
    style: { gradient: true }, size: SIZE({ panel: 320 })
  });

  add('chat-red-mail', __('Red chat – email', 'floating-social-contact-buttons'), 'chat', {
    layout: 'chat',
    header: { show: true, agent: __('Emma Clark', 'floating-social-contact-buttons'), role: __('Sales manager', 'floating-social-contact-buttons'), message: __('Hi! Any questions? Email us now.', 'floating-social-contact-buttons'), time: '15:29', online: true },
    items: [it('email', __('Email', 'floating-social-contact-buttons'), 'sales@site.ir')],
    cta: { show: true, text: __('Send email', 'floating-social-contact-buttons'), icon: 'fas:envelope' },
    opts: { chat_mode: 'button', close_style: 'inside' },
    trigger: { icon: 'fas:envelope', shape: 'rounded', pulse: false, badge_show: true },
    colors: { trigger_bg: '#c81e1e', trigger_color: '#fff', header_bg: '#c81e1e', header_bg2: '#c81e1e', header_text: '#fff', cta_bg: '#c81e1e', cta_color: '#fff' },
    style: { gradient: false }, size: SIZE({ panel: 300, trigger: 48, icon: 20 })
  });

  add('chat-icons-navy', __('Chat + messenger choice', 'floating-social-contact-buttons'), 'chat', {
    layout: 'chat',
    header: { show: true, agent: __('David Brown', 'floating-social-contact-buttons'), role: __('Education advisor', 'floating-social-contact-buttons'), message: __('Need help choosing a course?', 'floating-social-contact-buttons'), time: '12:30', online: true },
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id'), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'id'), it('sms', __('SMS', 'floating-social-contact-buttons'), PH)],
    cta: { show: false, text: __('Start a chat with:', 'floating-social-contact-buttons') },
    opts: { chat_mode: 'icons', close_style: 'inside' },
    trigger: { icon: 'fas:comments', shape: 'rounded' },
    colors: { trigger_bg: '#25258a', trigger_color: '#fff', header_bg: '#25258a', header_bg2: '#3730a3', header_text: '#fff', social_bg: '#25258a', social_color: '#fff', item_title: '#475569' },
    style: { network_colors: false }, size: SIZE({ panel: 300, trigger: 48, icon: 20 })
  });

  add('chat-teal', __('Teal green chat', 'floating-social-contact-buttons'), 'chat', {
    layout: 'chat',
    header: { show: true, agent: __('Olivia Wilson', 'floating-social-contact-buttons'), role: __('Account manager', 'floating-social-contact-buttons'), message: __('Placed your order? Ask us if you have any questions.', 'floating-social-contact-buttons'), time: '14:30', online: true },
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id'), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir')],
    cta: { show: false, text: __('Chat on:', 'floating-social-contact-buttons') },
    opts: { chat_mode: 'icons', close_style: 'inside' },
    trigger: { icon: 'fas:message', shape: 'rounded' },
    colors: { trigger_bg: '#0f766e', trigger_color: '#fff', header_bg: '#0f766e', header_bg2: '#0f766e', header_text: '#fff' },
    style: { network_colors: true }, size: SIZE({ panel: 300, trigger: 48, icon: 20 })
  });

  /* ---------- single buttons ---------- */
  add('cta-call-black', __('Black “Call us” button', 'floating-social-contact-buttons'), 'button', {
    layout: 'cta', items: [it('phone', __('Call', 'floating-social-contact-buttons'), TEL)],
    cta: { show: true, text: __('Call us now', 'floating-social-contact-buttons'), icon: 'fas:phone', item: '' },
    trigger: { shape: 'pill', pulse: false }, colors: { trigger_bg: '#0b0b0b', trigger_color: '#fff' }, size: SIZE({ trigger: 52, icon: 22 })
  });
  add('cta-chat-green', __('“Let’s talk” button', 'floating-social-contact-buttons'), 'button', {
    layout: 'cta', items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH)],
    cta: { show: true, text: __('Let’s talk', 'floating-social-contact-buttons'), icon: 'fab:whatsapp' },
    trigger: { shape: 'pill', pulse: true, greet_show: false }, colors: { trigger_bg: '#25d366', trigger_color: '#fff' }, size: SIZE({ trigger: 52, icon: 24 })
  });
  add('cta-navigate', __('Directions button', 'floating-social-contact-buttons'), 'button', {
    layout: 'cta', items: [it('neshan', __('Directions', 'floating-social-contact-buttons'), 'https://nshn.ir/')],
    cta: { show: true, text: __('Directions with Neshan', 'floating-social-contact-buttons'), icon: 'fab:waze' },
    trigger: { shape: 'pill' }, colors: { trigger_bg: '#38bdf8', trigger_color: '#fff' }, size: SIZE({ trigger: 52, icon: 24 })
  });
  add('bubble-whatsapp', __('WhatsApp bubble + badge', 'floating-social-contact-buttons'), 'button', {
    layout: 'bubble', items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH, { message: __('Hello', 'floating-social-contact-buttons') })],
    trigger: { icon: 'fab:whatsapp', shape: 'circle', pulse: true, badge_show: true, badge_text: '1', greet_show: true, greet_text: __('Hello 👋 Any questions? Message us on WhatsApp', 'floating-social-contact-buttons'), greet_delay: 3 },
    colors: { trigger_bg: '#25d366', trigger_color: '#fff' }, size: SIZE({ trigger: 58, icon: 30 })
  });
  add('bubble-telegram', __('Telegram bubble', 'floating-social-contact-buttons'), 'button', {
    layout: 'bubble', items: [it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'yourid')],
    trigger: { icon: 'fab:telegram', shape: 'circle', pulse: true, badge_show: true },
    colors: { trigger_bg: '#229ed9', trigger_color: '#fff' }, size: SIZE({ trigger: 58, icon: 32 })
  });
  add('bubble-eitaa', __('Eitaa bubble', 'floating-social-contact-buttons'), 'button', {
    layout: 'bubble', items: [it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'yourid')],
    trigger: { icon: 'efa:eitaa', shape: 'circle', pulse: true },
    colors: { trigger_bg: '#ef7f1a', trigger_color: '#fff' }, size: SIZE({ trigger: 58, icon: 30 })
  });

  /* ---------- bars & stacks ---------- */
  add('pill-purple', __('Purple pill bar', 'floating-social-contact-buttons'), 'bar', {
    layout: 'pill', position: POS('bottom-center', 0, 20),
    items: [it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir')],
    colors: { trigger_bg: '#5b4ee5', trigger_color: '#fff' }, size: SIZE({ trigger: 56, icon: 24 })
  });
  add('pill-slate', __('Four-icon pill bar', 'floating-social-contact-buttons'), 'bar', {
    layout: 'pill', position: POS('bottom-right'),
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir'), it('bale', __('Bale', 'floating-social-contact-buttons'), 'id')],
    colors: { trigger_bg: '#334155', trigger_color: '#fff' }, size: SIZE({ trigger: 52, icon: 22 })
  });
  add('pill-labels', __('Black bar with labels', 'floating-social-contact-buttons'), 'bar', {
    layout: 'pill', position: POS('bottom-center', 0, 20), opts: { pill_labels: true },
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('messenger', __('Messenger', 'floating-social-contact-buttons'), 'page'), it('sms', __('SMS', 'floating-social-contact-buttons'), PH), it('phone', __('Call', 'floating-social-contact-buttons'), TEL)],
    colors: { trigger_bg: '#111111', trigger_color: '#fff' }, size: SIZE({ trigger: 52, icon: 20 })
  });
  add('tabs-red', __('Red side tabs', 'floating-social-contact-buttons'), 'bar', {
    layout: 'tabs', position: POS('middle-left', 0, 0),
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('tracking', __('Order tracking', 'floating-social-contact-buttons'), '/track'), it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir'), it('website', __('Website', 'floating-social-contact-buttons'), '/')],
    opts: { tabs_expand: 'hover' },
    colors: { trigger_bg: '#e11d48', trigger_color: '#fff' }, size: SIZE({ trigger: 56, icon: 22, radius: 10 })
  });
  add('tabs-color', __('Colored network tabs', 'floating-social-contact-buttons'), 'bar', {
    layout: 'tabs', position: POS('middle-right', 0, 0),
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id'), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'id'), it('instagram', __('Instagram', 'floating-social-contact-buttons'), 'page'), it('phone', __('Call', 'floating-social-contact-buttons'), TEL)],
    opts: { tabs_expand: 'hover' }, style: { network_colors: true },
    colors: { trigger_bg: '#334155', trigger_color: '#fff' }, size: SIZE({ trigger: 54, icon: 22, radius: 10 })
  });
  add('dial-dark', __('Dark vertical floating menu', 'floating-social-contact-buttons'), 'stack', {
    layout: 'speeddial',
    items: [it('phone', __('Contact us', 'floating-social-contact-buttons'), TEL), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'id'), it('email', __('Email', 'floating-social-contact-buttons'), 'info@site.ir')],
    opts: { dial_labels: 'always', close_style: 'trigger' },
    trigger: { icon: 'fas:comments', shape: 'circle', pulse: true },
    colors: { trigger_bg: '#111827', trigger_color: '#fff', icon_bg: '#111827', icon_color: '#fff', label_bg: '#ffffff', label_color: '#111827' }, size: SIZE({ trigger: 54, icon: 22 })
  });
  add('dial-color', __('Colorful floating menu', 'floating-social-contact-buttons'), 'stack', {
    layout: 'speeddial',
    items: [it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('telegram', __('Telegram', 'floating-social-contact-buttons'), 'id'), it('bale', __('Bale', 'floating-social-contact-buttons'), 'id'), it('instagram', __('Instagram', 'floating-social-contact-buttons'), 'page'), it('phone', __('Call', 'floating-social-contact-buttons'), TEL)],
    opts: { dial_labels: 'hover', close_style: 'trigger' }, style: { network_colors: true },
    trigger: { icon: 'fas:plus', close_icon: 'fas:xmark', shape: 'circle', pulse: false },
    colors: { trigger_bg: '#2563eb', trigger_color: '#fff', label_bg: '#1e293b', label_color: '#fff' }, size: SIZE({ trigger: 56, icon: 24 })
  });
  add('bar-mobile', __('Mobile bottom bar (icons)', 'floating-social-contact-buttons'), 'bar', {
    layout: 'bar', position: POS('bottom-center', 0, 0),
    items: [it('phone', __('Call', 'floating-social-contact-buttons'), TEL), it('whatsapp', __('WhatsApp', 'floating-social-contact-buttons'), PH), it('eitaa', __('Eitaa', 'floating-social-contact-buttons'), 'id'), it('neshan', __('Route', 'floating-social-contact-buttons'), 'https://nshn.ir/')],
    display: { desktop: false, tablet: true, mobile: true }, opts: { bar_mode: 'icons' },
    colors: { trigger_bg: '#0f172a', trigger_color: '#fff' }, size: SIZE({ trigger: 56, icon: 20 })
  });
  add('bar-mobile-cta', __('Full-width mobile button', 'floating-social-contact-buttons'), 'bar', {
    layout: 'bar', position: POS('bottom-center', 0, 0),
    items: [it('phone', __('Call', 'floating-social-contact-buttons'), TEL)],
    cta: { show: true, text: __('Call an advisor now', 'floating-social-contact-buttons'), icon: 'fas:phone' },
    display: { desktop: false, tablet: true, mobile: true }, opts: { bar_mode: 'cta' },
    colors: { trigger_bg: '#22c55e', trigger_color: '#fff' }, size: SIZE({ trigger: 60, icon: 22 })
  });

  w.FSCB_TEMPLATES = T;
  w.FSCB_TEMPLATE_CATS = { all: __('Everyone', 'floating-social-contact-buttons'), panel: __('Contact cards', 'floating-social-contact-buttons'), list: __('Link lists', 'floating-social-contact-buttons'), chat: __('Chat bubble', 'floating-social-contact-buttons'), button: __('Single button', 'floating-social-contact-buttons'), stack: __('Floating menu', 'floating-social-contact-buttons'), bar: __('Bar & tabs', 'floating-social-contact-buttons') };
})(window);
