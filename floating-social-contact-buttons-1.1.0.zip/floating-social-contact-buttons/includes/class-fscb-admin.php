<?php
/**
 * Admin page (single-page app) + AJAX endpoints.
 *
 * @package FloatingSocialContactButtons
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin screen, assets and AJAX handlers.
 */
class FSCB_Admin {

	const CAP = 'manage_options';

	/** Menu icon (Font Awesome Free "phone", CC BY 4.0) as a data URI. */
	const MENU_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48cGF0aCBmaWxsPSIjYTdhYWFkIiBkPSJNMTY0LjkgMjQuNmMtNy43LTE4LjYtMjgtMjguNS00Ny40LTIzLjJsLTg4IDI0QzEyLjEgMzAuMiAwIDQ2IDAgNjRDMCAzMTEuNCAyMDAuNiA1MTIgNDQ4IDUxMmMxOCAwIDMzLjgtMTIuMSAzOC42LTI5LjVsMjQtODhjNS4zLTE5LjQtNC42LTM5LjctMjMuMi00Ny40bC05Ni00MGMtMTYuMy02LjgtMzUuMi0yLjEtNDYuMyAxMS42TDMwNC43IDM2OEMyMzQuMyAzMzQuNyAxNzcuMyAyNzcuNyAxNDQgMjA3LjNMMTkzLjMgMTY3YzEzLjctMTEuMiAxOC40LTMwIDExLjYtNDYuM2wtNDAtOTZ6Ii8+PC9zdmc+';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( array( 'save', 'delete', 'global', 'icon_add', 'icon_delete', 'search_posts' ) as $action ) {
			add_action( 'wp_ajax_fscb_' . $action, array( __CLASS__, 'ajax_' . $action ) );
		}
	}

	/**
	 * Top-level admin menu.
	 */
	public static function menu() {
		add_menu_page(
			__( 'Floating Social & Contact Buttons', 'floating-social-contact-buttons' ),
			__( 'Social Buttons', 'floating-social-contact-buttons' ),
			self::CAP,
			'fscb',
			array( __CLASS__, 'page' ),
			self::MENU_ICON,
			58
		);
	}

	/**
	 * Load the admin app only on its own screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function assets( $hook ) {
		if ( 'toplevel_page_fscb' !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fscb-front', FSCB_URL . 'assets/css/front.css', array(), FSCB_VERSION );
		wp_enqueue_style( 'fscb-admin', FSCB_URL . 'assets/css/admin.css', array( 'fscb-front' ), FSCB_VERSION );
		wp_enqueue_script( 'fscb-render', FSCB_URL . 'assets/js/render.js', array(), FSCB_VERSION, true );
		wp_enqueue_script( 'fscb-templates', FSCB_URL . 'assets/js/templates.js', array( 'wp-i18n' ), FSCB_VERSION, true );
		wp_enqueue_script( 'fscb-admin', FSCB_URL . 'assets/js/admin.js', array( 'wp-i18n', 'fscb-render', 'fscb-templates' ), FSCB_VERSION, true );
		wp_set_script_translations( 'fscb-templates', 'floating-social-contact-buttons', FSCB_DIR . 'languages' );
		wp_set_script_translations( 'fscb-admin', 'floating-social-contact-buttons', FSCB_DIR . 'languages' );

		$instances = array();
		foreach ( FSCB_Settings::all() as $inst ) {
			$instances[] = FSCB_Settings::fill( $inst );
		}

		wp_localize_script(
			'fscb-admin',
			'FSCB_ADMIN',
			array(
				'ajax'      => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'fscb_admin' ),
				'iconsUrl'  => FSCB_URL . 'assets/icons/',
				'packs'     => FSCB_Icons::available_packs(),
				'version'   => FSCB_VERSION,
				'instances' => $instances,
				'defaults'  => FSCB_Settings::defaults(),
				'itemDef'   => FSCB_Settings::item_defaults(),
				'networks'  => FSCB_Networks::all(),
				'ruleTypes' => FSCB_Conditions::types(),
				'global'    => FSCB_Settings::get_global(),
				'custom'    => (object) FSCB_Icons::custom_library(),
				'woo'       => class_exists( 'WooCommerce' ),
				'theme'     => get_template(),
				'i18n'      => FSCB_Frontend::ui_strings(),
				'rtl'       => is_rtl(),
			)
		);
	}

	/**
	 * Admin page shell; the app is rendered by admin.js.
	 */
	public static function page() {
		printf(
			'<div class="wrap fcp-wrap" dir="%1$s"><div id="fcp-app"><div class="fcp-loading">%2$s</div></div></div>',
			is_rtl() ? 'rtl' : 'ltr',
			esc_html__( 'Loading…', 'floating-social-contact-buttons' )
		);
	}

	/* ------------------------------------------------------------------ ajax */

	/**
	 * Capability + nonce check for every AJAX endpoint.
	 */
	private static function guard() {
		if ( ! current_user_can( self::CAP ) || ! check_ajax_referer( 'fscb_admin', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized request.', 'floating-social-contact-buttons' ) ), 403 );
		}
	}

	/**
	 * Read a POSTed string field (nonce already verified by guard()).
	 *
	 * @param string $key Field name.
	 * @return string Unslashed raw value; callers sanitize it for its type.
	 */
	private static function post_raw( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- verified in guard(); sanitized by each caller.
		return isset( $_POST[ $key ] ) ? (string) wp_unslash( $_POST[ $key ] ) : '';
	}

	/**
	 * Decode a JSON POST field.
	 *
	 * @param string $key Field name.
	 * @return array|null
	 */
	private static function json_param( $key ) {
		$val = json_decode( self::post_raw( $key ), true );
		return is_array( $val ) ? $val : null;
	}

	/**
	 * Save one widget instance.
	 */
	public static function ajax_save() {
		self::guard();
		$in = self::json_param( 'instance' );
		if ( ! $in ) {
			wp_send_json_error( array( 'message' => __( 'Invalid data.', 'floating-social-contact-buttons' ) ) );
		}
		$clean               = FSCB_Settings::sanitize( $in );
		$all                 = FSCB_Settings::all();
		$all[ $clean['id'] ] = $clean;
		update_option( FSCB_OPTION, $all, true );
		FSCB_Settings::payload( $clean ); // Warm the icon cache.
		FSCB_Icons::save_cache();
		self::flush_caches();
		wp_send_json_success( array( 'instance' => FSCB_Settings::fill( $clean ) ) );
	}

	/**
	 * Delete one widget instance.
	 */
	public static function ajax_delete() {
		self::guard();
		$id  = sanitize_key( self::post_raw( 'id' ) );
		$all = FSCB_Settings::all();
		unset( $all[ $id ] );
		update_option( FSCB_OPTION, $all, true );
		self::flush_caches();
		wp_send_json_success();
	}

	/**
	 * Save global settings.
	 */
	public static function ajax_global() {
		self::guard();
		$in  = self::json_param( 'global' );
		$in  = $in ? $in : array();
		$def = FSCB_Settings::global_defaults();
		$out = array(
			'country_code' => substr( preg_replace( '/\D/', '', (string) ( $in['country_code'] ?? $def['country_code'] ) ), 0, 4 ),
			'bp_tablet'    => min( 2560, max( 480, (int) ( $in['bp_tablet'] ?? $def['bp_tablet'] ) ) ),
			'bp_mobile'    => min( 1920, max( 320, (int) ( $in['bp_mobile'] ?? $def['bp_mobile'] ) ) ),
		);
		update_option( FSCB_GLOBAL_OPTION, $out );
		self::flush_caches();
		wp_send_json_success( array( 'global' => $out ) );
	}

	/**
	 * Add a custom SVG icon to the library.
	 */
	public static function ajax_icon_add() {
		self::guard();
		$svg  = FSCB_Icons::sanitize_svg( self::post_raw( 'svg' ) );
		$name = sanitize_text_field( self::post_raw( 'name' ) );
		$name = '' === $name ? 'icon' : mb_substr( $name, 0, 60 );
		if ( '' === $svg ) {
			wp_send_json_error( array( 'message' => __( 'The SVG code is not valid.', 'floating-social-contact-buttons' ) ) );
		}
		$lib        = FSCB_Icons::custom_library();
		$id         = 'c' . strtolower( wp_generate_password( 6, false ) );
		$lib[ $id ] = array(
			'name' => $name,
			'svg'  => $svg,
		);
		update_option( 'fscb_custom_icons', $lib, false );
		wp_send_json_success(
			array(
				'id'   => $id,
				'icon' => $lib[ $id ],
			)
		);
	}

	/**
	 * Remove a custom SVG icon.
	 */
	public static function ajax_icon_delete() {
		self::guard();
		$id  = sanitize_key( self::post_raw( 'id' ) );
		$lib = FSCB_Icons::custom_library();
		unset( $lib[ $id ] );
		update_option( 'fscb_custom_icons', $lib, false );
		wp_send_json_success();
	}

	/**
	 * Search posts and terms for the display-rule picker.
	 */
	public static function ajax_search_posts() {
		self::guard();
		$q     = sanitize_text_field( self::post_raw( 'q' ) );
		$res   = array();
		$posts = get_posts(
			array(
				's'              => $q,
				'post_type'      => array_values( get_post_types( array( 'public' => true ) ) ),
				'posts_per_page' => 15,
				'post_status'    => 'publish',
			)
		);
		foreach ( $posts as $p ) {
			$res[] = array(
				'id'    => $p->ID,
				'title' => get_the_title( $p ),
				'type'  => $p->post_type,
			);
		}
		$terms = get_terms(
			array(
				'search'     => $q,
				'number'     => 10,
				'hide_empty' => false,
				'taxonomy'   => get_taxonomies( array( 'public' => true ) ),
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$res[] = array(
					'id'    => $t->term_id,
					'title' => $t->name,
					'type'  => 'term:' . $t->taxonomy,
				);
			}
		}
		wp_send_json_success( $res );
	}

	/**
	 * Purge common page caches so changes appear immediately.
	 */
	private static function flush_caches() {
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( has_action( 'litespeed_purge_all' ) ) {
			do_action( 'litespeed_purge_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache public API.
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
		}
		do_action( 'fscb_settings_saved' );
	}
}
