<?php
/**
 * Icon resolver. Every icon is turned into inline SVG at save time, so the
 * front end never loads an icon font.
 *
 * Keys:  fas:name | far:name | fab:name  (Font Awesome 6 Free, CC BY 4.0)
 *        efa:name                         (Iranian icons from the Persian Elementor plugin, GPLv2 or later)
 *        cus:id                           (custom SVG uploaded/pasted by an administrator)
 *        img:url                          (image from the media library)
 *
 * @package FloatingSocialContactButtons
 */

defined( 'ABSPATH' ) || exit;

/**
 * Icon packs, custom icon library and SVG sanitizer.
 */
class FSCB_Icons {

	const PACKS = array( 'fas', 'far', 'fab', 'efa' );

	/** Used when an optional pack (e.g. the Iranian icons) is not shipped. */
	const FALLBACK = array(
		'efa:aparat'  => 'fas:circle-play',
		'efa:neshan'  => 'fas:location-dot',
		'efa:cloob'   => 'fas:users',
		'efa:default' => 'fas:comment-dots',
	);

	/** Largest custom SVG accepted, in bytes. */
	const MAX_SVG_BYTES = 100000;

	/**
	 * Decoded icon packs.
	 *
	 * @var array
	 */
	private static $packs = array();

	/**
	 * Rendered-icon cache (option fscb_icon_cache).
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Whether the cache must be written on shutdown.
	 *
	 * @var bool
	 */
	private static $cache_dirty = false;

	/**
	 * Icon packs whose JSON file is present.
	 *
	 * @return string[]
	 */
	public static function available_packs() {
		return array_values(
			array_filter(
				self::PACKS,
				function ( $p ) {
					return file_exists( FSCB_DIR . 'assets/icons/' . $p . '.json' );
				}
			)
		);
	}

	/**
	 * Decode one icon pack (local file shipped with the plugin).
	 *
	 * @param string $p Pack key.
	 * @return array
	 */
	private static function pack( $p ) {
		if ( ! isset( self::$packs[ $p ] ) ) {
			$file              = FSCB_DIR . 'assets/icons/' . $p . '.json';
			$data              = file_exists( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin file.
			self::$packs[ $p ] = is_array( $data ) ? $data : array();
		}
		return self::$packs[ $p ];
	}

	/**
	 * Custom icon library saved by administrators.
	 *
	 * @return array
	 */
	public static function custom_library() {
		$lib = get_option( 'fscb_custom_icons', array() );
		return is_array( $lib ) ? $lib : array();
	}

	/**
	 * Return inline SVG/IMG markup for an icon key, or '' if unknown.
	 * Used icons are cached in a small option so the large icon packs are only
	 * parsed once (when an icon is used for the first time), never per request.
	 *
	 * @param string $key Icon key.
	 * @return string
	 */
	public static function render( $key ) {
		$key = (string) $key;
		if ( '' === $key || false === strpos( $key, ':' ) ) {
			return '';
		}
		if ( null === self::$cache ) {
			$c           = get_option( 'fscb_icon_cache', array() );
			self::$cache = ( is_array( $c ) && ( $c['_v'] ?? '' ) === FSCB_VERSION ) ? $c : array( '_v' => FSCB_VERSION );
		}
		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}
		$svg = self::build( $key );
		if ( '' !== $svg && 0 !== strpos( $key, 'cus:' ) && 0 !== strpos( $key, 'img:' ) ) {
			self::$cache[ $key ] = $svg;
			if ( ! self::$cache_dirty ) {
				self::$cache_dirty = true;
				add_action( 'shutdown', array( __CLASS__, 'save_cache' ) );
			}
		}
		return $svg;
	}

	/**
	 * Persist the rendered-icon cache.
	 */
	public static function save_cache() {
		if ( is_array( self::$cache ) ) {
			update_option( 'fscb_icon_cache', self::$cache, true );
		}
	}

	/**
	 * Build the markup of one icon.
	 *
	 * @param string $key Icon key.
	 * @return string
	 */
	private static function build( $key ) {
		list( $p, $name ) = explode( ':', $key, 2 );

		if ( 'img' === $p ) {
			$url = esc_url( $name, array( 'http', 'https' ) );
			return '' === $url ? '' : '<img class="fcp-i fcp-i--img" src="' . $url . '" alt="" loading="lazy" decoding="async">';
		}
		if ( 'cus' === $p ) {
			$lib = self::custom_library();
			return isset( $lib[ $name ]['svg'] ) ? self::sanitize_svg( $lib[ $name ]['svg'], true ) : '';
		}
		if ( ! in_array( $p, self::PACKS, true ) ) {
			return '';
		}
		$pack = self::pack( $p );
		if ( empty( $pack[ $name ] ) ) {
			if ( 'efa' === $p ) {
				return self::build( self::FALLBACK[ $key ] ?? self::FALLBACK['efa:default'] );
			}
			return '';
		}
		$i = $pack[ $name ];
		$w = (int) $i[0];
		$h = (int) $i[1];
		$d = esc_attr( $i[2] );
		$t = isset( $i[3] ) ? (int) $i[3] : 0;

		if ( 1 === $t ) { // Flipped font glyph (Iranian icon font).
			return '<svg class="fcp-i" viewBox="0 0 ' . $w . ' 1024" aria-hidden="true" focusable="false"><path fill="currentColor" transform="matrix(1 0 0 -1 0 960)" d="' . $d . '"/></svg>';
		}
		if ( 2 === $t ) { // Stroke icon.
			return '<svg class="fcp-i" viewBox="0 0 ' . $w . ' ' . $h . '" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" d="' . $d . '"/></svg>';
		}
		return '<svg class="fcp-i" viewBox="0 0 ' . $w . ' ' . $h . '" aria-hidden="true" focusable="false"><path fill="currentColor" d="' . $d . '"/></svg>';
	}

	/* ------------------------------------------------------------ sanitizer */

	// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMDocument/DOMNode property names.

	/**
	 * Elements and attributes allowed in custom SVG icons.
	 *
	 * @return array<string,array<string,bool>>
	 */
	private static function allowed_svg() {
		$presentation = array(
			'id'                => true,
			'class'             => true,
			'fill'              => true,
			'fill-rule'         => true,
			'clip-rule'         => true,
			'fill-opacity'      => true,
			'stroke'            => true,
			'stroke-width'      => true,
			'stroke-linecap'    => true,
			'stroke-linejoin'   => true,
			'stroke-miterlimit' => true,
			'stroke-opacity'    => true,
			'stroke-dasharray'  => true,
			'stroke-dashoffset' => true,
			'opacity'           => true,
			'transform'         => true,
			'clip-path'         => true,
			'mask'              => true,
		);
		return array(
			'svg'            => $presentation + array(
				'xmlns'               => true,
				'viewbox'             => true,
				'width'               => true,
				'height'              => true,
				'preserveaspectratio' => true,
				'aria-hidden'         => true,
				'focusable'           => true,
				'role'                => true,
			),
			'g'              => $presentation,
			'path'           => $presentation + array( 'd' => true ),
			'circle'         => $presentation + array(
				'cx' => true,
				'cy' => true,
				'r'  => true,
			),
			'ellipse'        => $presentation + array(
				'cx' => true,
				'cy' => true,
				'rx' => true,
				'ry' => true,
			),
			'rect'           => $presentation + array(
				'x'      => true,
				'y'      => true,
				'width'  => true,
				'height' => true,
				'rx'     => true,
				'ry'     => true,
			),
			'line'           => $presentation + array(
				'x1' => true,
				'y1' => true,
				'x2' => true,
				'y2' => true,
			),
			'polyline'       => $presentation + array( 'points' => true ),
			'polygon'        => $presentation + array( 'points' => true ),
			'defs'           => array(),
			'title'          => array(),
			'clippath'       => array(
				'id'            => true,
				'clippathunits' => true,
			),
			'mask'           => array(
				'id'        => true,
				'x'         => true,
				'y'         => true,
				'width'     => true,
				'height'    => true,
				'maskunits' => true,
			),
			'lineargradient' => array(
				'id'                => true,
				'x1'                => true,
				'y1'                => true,
				'x2'                => true,
				'y2'                => true,
				'gradientunits'     => true,
				'gradienttransform' => true,
			),
			'radialgradient' => array(
				'id'                => true,
				'cx'                => true,
				'cy'                => true,
				'r'                 => true,
				'fx'                => true,
				'fy'                => true,
				'gradientunits'     => true,
				'gradienttransform' => true,
			),
			'stop'           => array(
				'offset'       => true,
				'stop-color'   => true,
				'stop-opacity' => true,
			),
		);
	}

	/**
	 * Validate one attribute value. Only local references such as url(#id) are
	 * allowed; anything that could reach another resource or run code is dropped.
	 *
	 * @param string $name  Lower-case attribute name.
	 * @param string $value Attribute value.
	 * @return bool
	 */
	private static function safe_value( $name, $value ) {
		$value = trim( (string) $value );
		if ( 'xmlns' === $name ) {
			return 'http://www.w3.org/2000/svg' === $value;
		}
		if ( strlen( $value ) > 20000 || preg_match( '/[<>`\\\\]|&#|expression\s*\(|@import/i', $value ) ) {
			return false;
		}
		if ( false !== stripos( $value, 'url(' ) ) {
			// Only a single same-document reference, e.g. url(#clip0).
			return (bool) preg_match( '/^url\(\s*[\'"]?#[A-Za-z_][\w.\-]*[\'"]?\s*\)$/', $value );
		}
		// No URI schemes (javascript:, data:, http: …) in any other attribute.
		return false === strpos( $value, ':' );
	}

	/**
	 * Strict SVG sanitizer for administrator-supplied icons.
	 *
	 * The markup is parsed with DOMDocument (no network, no DTD/entities), every
	 * element/attribute is checked against an allowlist, attribute values are
	 * validated, and the result is passed through wp_kses() as a second layer.
	 *
	 * @param string $svg       Raw SVG markup.
	 * @param bool   $add_class Add the icon class and ARIA attributes to the root element.
	 * @return string Sanitized SVG or '' when it cannot be made safe.
	 */
	public static function sanitize_svg( $svg, $add_class = false ) {
		$svg = (string) $svg;
		if ( '' === $svg || strlen( $svg ) > self::MAX_SVG_BYTES || preg_match( '/<!(DOCTYPE|ENTITY)/i', $svg ) ) {
			return '';
		}
		if ( ! preg_match( '#<svg[\s\S]*</svg>#i', $svg, $m ) ) {
			return '';
		}
		$allowed = self::allowed_svg();
		$clean   = '';
		$raw     = $m[0];
		// Icons pasted without a namespace still parse as SVG.
		if ( ! preg_match( '#^<svg\b[^>]*\sxmlns\s*=#i', $raw ) ) {
			$raw = preg_replace( '#^<svg\b#i', '<svg xmlns="http://www.w3.org/2000/svg"', $raw, 1 );
		}

		if ( class_exists( 'DOMDocument' ) ) {
			$prev = libxml_use_internal_errors( true );
			$doc  = new DOMDocument();
			$ok   = $doc->loadXML( $raw, LIBXML_NONET | LIBXML_NOBLANKS | LIBXML_COMPACT );
			libxml_clear_errors();
			libxml_use_internal_errors( $prev );
			if ( ! $ok || ! $doc->documentElement || 'svg' !== strtolower( $doc->documentElement->localName ) ) {
				return '';
			}
			self::clean_node( $doc->documentElement, $allowed );
			$clean = $doc->saveXML( $doc->documentElement );
		} else {
			$clean = preg_replace( '#<(script|style|foreignObject)[\s\S]*?</\1>#i', '', $raw );
		}
		if ( ! is_string( $clean ) || '' === $clean ) {
			return '';
		}

		// Second layer: WordPress' own HTML filter with the same allowlist.
		$clean = wp_kses( $clean, $allowed );
		$clean = preg_replace_callback(
			'#\s([a-z\-:]+)\s*=\s*("[^"]*"|\'[^\']*\')#i',
			function ( $a ) {
				return self::safe_value( strtolower( $a[1] ), trim( $a[2], '"\'' ) ) ? $a[0] : '';
			},
			$clean
		);

		// Drop fixed width/height on the root so CSS controls the size.
		$clean = preg_replace_callback(
			'#<svg\b[^>]*>#i',
			function ( $mm ) use ( $add_class ) {
				$tag = preg_replace( '#\s(width|height)="[^"]*"#i', '', $mm[0] );
				if ( $add_class ) {
					$tag = preg_replace( '#\s(class|aria-hidden|focusable)="[^"]*"#i', '', $tag );
					$tag = str_replace( '<svg', '<svg class="fcp-i" aria-hidden="true" focusable="false"', $tag );
				}
				return $tag;
			},
			$clean,
			1
		);
		return false !== stripos( (string) $clean, '<svg' ) ? (string) $clean : '';
	}

	/**
	 * Recursively remove disallowed nodes and attributes.
	 *
	 * @param DOMElement $el      Element to clean.
	 * @param array      $allowed Allowlist from allowed_svg().
	 */
	private static function clean_node( $el, $allowed ) {
		$tag = strtolower( $el->localName );
		// Attributes (iterate over a copy because we remove while looping).
		$attrs = array();
		foreach ( $el->attributes as $attr ) {
			$attrs[] = $attr;
		}
		foreach ( $attrs as $attr ) {
			$name = strtolower( $attr->nodeName );
			if ( ! isset( $allowed[ $tag ][ $name ] ) || ! self::safe_value( $name, $attr->nodeValue ) ) {
				$el->removeAttributeNode( $attr );
			}
		}
		// Children.
		$children = array();
		foreach ( $el->childNodes as $child ) {
			$children[] = $child;
		}
		foreach ( $children as $child ) {
			if ( XML_ELEMENT_NODE === $child->nodeType ) {
				if ( isset( $allowed[ strtolower( $child->localName ) ] ) && 'http://www.w3.org/2000/svg' === $child->namespaceURI ) {
					self::clean_node( $child, $allowed );
				} else {
					$el->removeChild( $child );
				}
			} elseif ( XML_TEXT_NODE === $child->nodeType && 'title' === $tag ) {
				continue;
			} elseif ( XML_TEXT_NODE !== $child->nodeType || '' !== trim( $child->nodeValue ) ) {
				$el->removeChild( $child ); // Comments, CDATA, processing instructions, stray text.
			}
		}
	}
	// phpcs:enable
}
