<?php
/**
 * Elementor widget: place a contact widget (or only its contacts / socials)
 * inline anywhere – footer templates, WoodMart HTML blocks, Theme Builder…
 */

defined( 'ABSPATH' ) || exit;

class FSCB_Elementor_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'fcp-inline';
	}

	public function get_title() {
		return __( 'Contact / social buttons', 'floating-social-contact-buttons' );
	}

	public function get_icon() {
		return 'eicon-share';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'contact', 'social', 'whatsapp', __( 'Contact', 'floating-social-contact-buttons' ), __( 'Social networks', 'floating-social-contact-buttons' ), __( 'WhatsApp', 'floating-social-contact-buttons' ), __( 'Eitaa', 'floating-social-contact-buttons' ) );
	}

	public function get_style_depends() {
		return array( 'fscb-front' );
	}

	public function get_script_depends() {
		return array( 'fscb-render' );
	}

	protected function register_controls() {
		$opts = array();
		foreach ( FSCB_Settings::all() as $id => $inst ) {
			$opts[ $id ] = $inst['name'] ?? $id;
		}

		$this->start_controls_section( 'content', array( 'label' => __( 'Settings', 'floating-social-contact-buttons' ) ) );

		$this->add_control(
			'instance',
			array(
				'label'       => __( 'Contact widget', 'floating-social-contact-buttons' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $opts,
				'default'     => $opts ? array_key_first( $opts ) : '',
				'description' => $opts ? __( 'Appearance and items are read from the plugin settings.', 'floating-social-contact-buttons' ) : __( 'Create a widget first in the “Social Buttons” menu.', 'floating-social-contact-buttons' ),
			)
		);

		$this->add_control(
			'part',
			array(
				'label'   => __( 'What should be displayed?', 'floating-social-contact-buttons' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'socials',
				'options' => array(
					'socials' => __( 'Social network icons only', 'floating-social-contact-buttons' ),
					'items'   => __( 'Contact items only', 'floating-social-contact-buttons' ),
					'all'     => __( 'Whole panel (header + contacts + social links)', 'floating-social-contact-buttons' ),
				),
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Alignment', 'floating-social-contact-buttons' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Start', 'floating-social-contact-buttons' ),
						'icon'  => 'eicon-h-align-right',
					),
					'center'     => array(
						'title' => __( 'Center', 'floating-social-contact-buttons' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'End', 'floating-social-contact-buttons' ),
						'icon'  => 'eicon-h-align-left',
					),
				),
				'selectors' => array( '{{WRAPPER}} .fcp-inline .fcp-socials__list, {{WRAPPER}} .fcp-inline' => 'justify-content: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( empty( $s['instance'] ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p style="padding:12px;border:1px dashed #ccc">' . esc_html__( 'Create a widget first in Dashboard › Social Buttons.', 'floating-social-contact-buttons' ) . '</p>';
			}
			return;
		}
		$html = FSCB_Frontend::shortcode(
			array(
				'id'   => $s['instance'],
				'part' => $s['part'],
			)
		);
		// Markup is built from escaped attributes and a JSON payload encoded with JSON_HEX_TAG (see FSCB_Frontend::shortcode()).
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
