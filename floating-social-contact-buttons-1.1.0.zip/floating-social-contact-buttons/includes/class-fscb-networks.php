<?php
/**
 * Contact channels / social networks catalogue and link builder.
 */

defined( 'ABSPATH' ) || exit;

class FSCB_Networks {

	/**
	 * kind: phone | user | url | email | text
	 * pattern placeholders: {v} raw value, {u} username (no @), {intl} international digits, {msg} encoded prefilled message
	 */
	public static function all() {
		$n = array(
			// Contact.
			'phone'       => array( 'phone', __( 'Phone call', 'floating-social-contact-buttons' ), 'fas:phone', '#16a34a', 'tel:{v}', __( 'Contact', 'floating-social-contact-buttons' ) ),
			'mobile'      => array( 'phone', __( 'Mobile', 'floating-social-contact-buttons' ), 'fas:mobile-screen-button', '#0ea5e9', 'tel:{v}', __( 'Contact', 'floating-social-contact-buttons' ) ),
			'support'     => array( 'phone', __( 'Support / consultation', 'floating-social-contact-buttons' ), 'fas:headset', '#c59d5f', 'tel:{v}', __( 'Contact', 'floating-social-contact-buttons' ) ),
			'sms'         => array( 'phone', __( 'SMS', 'floating-social-contact-buttons' ), 'fas:comment-sms', '#6366f1', 'sms:{v}{smsbody}', __( 'Contact', 'floating-social-contact-buttons' ) ),
			'email'       => array( 'email', __( 'Email', 'floating-social-contact-buttons' ), 'fas:envelope', '#ea4335', 'mailto:{v}{subject}', __( 'Contact', 'floating-social-contact-buttons' ) ),
			// Iranian messengers.
			'eitaa'       => array( 'user', __( 'Eitaa', 'floating-social-contact-buttons' ), 'efa:eitaa', '#ef7f1a', 'https://eitaa.com/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'bale'        => array( 'user', __( 'Bale', 'floating-social-contact-buttons' ), 'efa:bale', '#3bb27a', 'https://ble.ir/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'rubika'      => array( 'user', __( 'Rubika', 'floating-social-contact-buttons' ), 'efa:rubika', '#8a2be2', 'https://rubika.ir/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'soroush'     => array( 'user', __( 'Soroush Plus', 'floating-social-contact-buttons' ), 'efa:soroush', '#1e88e5', 'https://splus.ir/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'gap'         => array( 'user', __( 'Gap', 'floating-social-contact-buttons' ), 'efa:gap', '#00a3e0', 'https://gap.im/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'igap'        => array( 'user', __( 'iGap', 'floating-social-contact-buttons' ), 'fas:comment-dots', '#0c9fd8', 'https://igap.net/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'bisphone'    => array( 'user', __( 'BisPhone', 'floating-social-contact-buttons' ), 'efa:bisphone', '#00b2b3', 'https://bisphone.com/{u}', __( 'Iranian messengers', 'floating-social-contact-buttons' ) ),
			'aparat'      => array( 'user', __( 'Aparat', 'floating-social-contact-buttons' ), 'efa:aparat', '#ed145b', 'https://www.aparat.com/{u}', __( 'Iranian social networks', 'floating-social-contact-buttons' ) ),
			'cloob'       => array( 'user', __( 'Cloob', 'floating-social-contact-buttons' ), 'efa:cloob', '#f7941d', 'https://www.cloob.com/{u}', __( 'Iranian social networks', 'floating-social-contact-buttons' ) ),
			'neshan'      => array( 'url', __( 'Neshan (navigation)', 'floating-social-contact-buttons' ), 'efa:neshan', '#1f6feb', '{v}', __( 'Maps', 'floating-social-contact-buttons' ) ),
			'balad'       => array( 'url', __( 'Balad (navigation)', 'floating-social-contact-buttons' ), 'fas:location-dot', '#2a7cf6', '{v}', __( 'Maps', 'floating-social-contact-buttons' ) ),
			// International messengers.
			'whatsapp'    => array( 'phone', __( 'WhatsApp', 'floating-social-contact-buttons' ), 'fab:whatsapp', '#25d366', 'https://wa.me/{intl}{text}', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			'telegram'    => array( 'user', __( 'Telegram', 'floating-social-contact-buttons' ), 'fab:telegram', '#229ed9', 'https://t.me/{u}', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			'messenger'   => array( 'user', __( 'Messenger', 'floating-social-contact-buttons' ), 'fab:facebook-messenger', '#0084ff', 'https://m.me/{u}', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			'viber'       => array( 'phone', __( 'Viber', 'floating-social-contact-buttons' ), 'fab:viber', '#7360f2', 'viber://chat?number=%2B{intl}', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			'skype'       => array( 'user', __( 'Skype', 'floating-social-contact-buttons' ), 'fab:skype', '#00aff0', 'skype:{u}?chat', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			'discord'     => array( 'url', __( 'Discord', 'floating-social-contact-buttons' ), 'fab:discord', '#5865f2', '{v}', __( 'Messengers', 'floating-social-contact-buttons' ) ),
			// Social networks.
			'instagram'   => array( 'user', __( 'Instagram', 'floating-social-contact-buttons' ), 'fab:instagram', '#e1306c', 'https://instagram.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'youtube'     => array( 'user', __( 'YouTube', 'floating-social-contact-buttons' ), 'fab:youtube', '#ff0000', 'https://youtube.com/@{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'linkedin'    => array( 'user', __( 'LinkedIn', 'floating-social-contact-buttons' ), 'fab:linkedin-in', '#0a66c2', 'https://www.linkedin.com/in/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'x'           => array( 'user', __( 'X (Twitter)', 'floating-social-contact-buttons' ), 'fab:x-twitter', '#111111', 'https://x.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'facebook'    => array( 'user', __( 'Facebook', 'floating-social-contact-buttons' ), 'fab:facebook-f', '#1877f2', 'https://facebook.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'threads'     => array( 'user', __( 'Threads', 'floating-social-contact-buttons' ), 'fab:threads', '#111111', 'https://www.threads.net/@{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'tiktok'      => array( 'user', __( 'TikTok', 'floating-social-contact-buttons' ), 'fab:tiktok', '#111111', 'https://www.tiktok.com/@{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'pinterest'   => array( 'user', __( 'Pinterest', 'floating-social-contact-buttons' ), 'fab:pinterest-p', '#e60023', 'https://pinterest.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'snapchat'    => array( 'user', __( 'Snapchat', 'floating-social-contact-buttons' ), 'fab:snapchat', '#f7d000', 'https://snapchat.com/add/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'github'      => array( 'user', __( 'GitHub', 'floating-social-contact-buttons' ), 'fab:github', '#24292f', 'https://github.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'behance'     => array( 'user', __( 'Behance', 'floating-social-contact-buttons' ), 'fab:behance', '#1769ff', 'https://www.behance.net/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'dribbble'    => array( 'user', __( 'Dribbble', 'floating-social-contact-buttons' ), 'fab:dribbble', '#ea4c89', 'https://dribbble.com/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'twitch'      => array( 'user', __( 'Twitch', 'floating-social-contact-buttons' ), 'fab:twitch', '#9146ff', 'https://twitch.tv/{u}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			'spotify'     => array( 'url', __( 'Spotify', 'floating-social-contact-buttons' ), 'fab:spotify', '#1db954', '{v}', __( 'Social networks', 'floating-social-contact-buttons' ) ),
			// Maps and links.
			'google_maps' => array( 'text', __( 'Google Maps', 'floating-social-contact-buttons' ), 'fas:map-location-dot', '#34a853', 'https://www.google.com/maps/search/?api=1&query={enc}', __( 'Maps', 'floating-social-contact-buttons' ) ),
			'waze'        => array( 'text', __( 'Waze', 'floating-social-contact-buttons' ), 'fab:waze', '#33ccff', 'https://waze.com/ul?q={enc}', __( 'Maps', 'floating-social-contact-buttons' ) ),
			'website'     => array( 'url', __( 'Website', 'floating-social-contact-buttons' ), 'fas:globe', '#334155', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
			'faq'         => array( 'url', __( 'FAQ', 'floating-social-contact-buttons' ), 'fas:circle-question', '#0ea5e9', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
			'tracking'    => array( 'url', __( 'Order tracking', 'floating-social-contact-buttons' ), 'fas:truck-fast', '#f97316', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
			'booking'     => array( 'url', __( 'Book an appointment', 'floating-social-contact-buttons' ), 'fas:calendar-check', '#8b5cf6', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
			'download'    => array( 'url', __( 'Download catalog', 'floating-social-contact-buttons' ), 'fas:file-arrow-down', '#0f766e', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
			'custom'      => array( 'url', __( 'Custom link', 'floating-social-contact-buttons' ), 'fas:link', '#475569', '{v}', __( 'Links', 'floating-social-contact-buttons' ) ),
		);

		$out = array();
		foreach ( $n as $key => $r ) {
			$out[ $key ] = array(
				'kind'    => $r[0],
				'label'   => $r[1],
				'icon'    => $r[2],
				'color'   => $r[3],
				'pattern' => $r[4],
				'group'   => $r[5],
			);
		}
		return apply_filters( 'fscb_networks', $out );
	}

	/** Convert Persian/Arabic digits to Latin. */
	public static function latin_digits( $s ) {
		return strtr(
			(string) $s,
			array(
				'۰' => '0',
				'۱' => '1',
				'۲' => '2',
				'۳' => '3',
				'۴' => '4',
				'۵' => '5',
				'۶' => '6',
				'۷' => '7',
				'۸' => '8',
				'۹' => '9',
				'٠' => '0',
				'١' => '1',
				'٢' => '2',
				'٣' => '3',
				'٤' => '4',
				'٥' => '5',
				'٦' => '6',
				'٧' => '7',
				'٨' => '8',
				'٩' => '9',
			)
		);
	}

	/** Build final href for a contact item. */
	public static function href( $item, $country_code = '98' ) {
		$all = self::all();
		$net = isset( $all[ $item['network'] ] ) ? $all[ $item['network'] ] : $all['custom'];
		$v   = trim( self::latin_digits( isset( $item['value'] ) ? $item['value'] : '' ) );
		if ( '' === $v ) {
			return '';
		}

		// A full URL / scheme typed by the user always wins.
		if ( preg_match( '#^(https?:|tel:|mailto:|sms:|viber:|skype:|tg:|whatsapp:|/|\#)#i', $v ) ) {
			return $v;
		}

		$msg    = isset( $item['message'] ) ? trim( $item['message'] ) : '';
		$digits = preg_replace( '/[^0-9+]/', '', $v );
		$intl   = ltrim( $digits, '+' );
		if ( 0 === strpos( $intl, '00' ) ) {
			$intl = substr( $intl, 2 );
		} elseif ( 0 === strpos( $intl, '0' ) && '+' !== substr( $digits, 0, 1 ) ) {
			$intl = preg_replace( '/[^0-9]/', '', $country_code ) . substr( $intl, 1 );
		}

		$map  = array(
			'{v}'       => 'phone' === $net['kind'] ? $digits : $v,
			'{u}'       => ltrim( $v, '@' ),
			'{intl}'    => $intl,
			'{enc}'     => rawurlencode( $v ),
			'{text}'    => '' !== $msg ? '?text=' . rawurlencode( $msg ) : '',
			'{smsbody}' => '' !== $msg ? '?body=' . rawurlencode( $msg ) : '',
			'{subject}' => '' !== $msg ? '?subject=' . rawurlencode( $msg ) : '',
		);
		$href = strtr( $net['pattern'], $map );

		// URL-type network but user typed a bare domain.
		if ( '{v}' === $net['pattern'] && ! preg_match( '#^[a-z]+:#i', $href ) ) {
			$href = 'https://' . ltrim( $href, '/' );
		}
		// Reject unsafe schemes such as javascript: and data: before exposing the link to visitors.
		$allowed_protocols = array_unique( array_merge( wp_allowed_protocols(), array( 'sms', 'viber', 'skype', 'tg', 'whatsapp' ) ) );
		return esc_url_raw( $href, $allowed_protocols );
	}
}
