<?php
/**
 * Front end: decides which instances show on the current request, prints
 * one small JSON payload and loads the CSS/JS only when needed.
 *
 * @package FloatingSocialContactButtons
 */

defined( 'ABSPATH' ) || exit;

/**
 * Front-end output.
 */
class FSCB_Frontend {

	/**
	 * Floating instances shown on this request.
	 *
	 * @var array
	 */
	private static $floating = array();

	/**
	 * Instances printed inline through the shortcode / Elementor widget.
	 *
	 * @var array
	 */
	private static $inline = array();

	/**
	 * Whether the floating payload was already printed.
	 *
	 * @var bool
	 */
	private static $printed = false;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_shortcodes' ) );
		add_action( 'wp', array( __CLASS__, 'collect' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register' ), 5 );
		add_action( 'wp_footer', array( __CLASS__, 'print_data' ), 20 );
	}

	/**
	 * [fscb] shortcode (plus the pre-release [fcp] name on sites that used it).
	 */
	public static function register_shortcodes() {
		add_shortcode( 'fscb', array( __CLASS__, 'shortcode' ) );
		if ( get_option( 'fscb_legacy_shortcodes' ) && ! shortcode_exists( 'fcp' ) ) {
			add_shortcode( 'fcp', array( __CLASS__, 'shortcode' ) );
		}
	}

	/**
	 * Translated strings used by render.js (keeps wp-i18n off the front end).
	 *
	 * @return array<string,string>
	 */
	public static function ui_strings() {
		return array(
			'close'     => __( 'Close', 'floating-social-contact-buttons' ),
			'contact'   => __( 'Contact', 'floating-social-contact-buttons' ),
			'contactUs' => __( 'Contact us', 'floating-social-contact-buttons' ),
			'startChat' => __( 'Start a chat with:', 'floating-social-contact-buttons' ),
		);
	}

	/**
	 * True inside page-builder preview frames.
	 *
	 * @return bool
	 */
	public static function is_builder_preview() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only detection of builder preview frames.
		if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['fl_builder'] ) || isset( $_GET['et_fb'] ) ) {
			return true;
		}
		// phpcs:enable
		return class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode();
	}

	/**
	 * Decide which floating instances appear on this request.
	 */
	public static function collect() {
		if ( is_admin() || is_feed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || is_embed() ) {
			return;
		}
		$preview = self::is_builder_preview();
		foreach ( FSCB_Settings::all() as $raw ) {
			$inst = FSCB_Settings::fill( $raw );
			if ( empty( $inst['enabled'] ) ) {
				continue;
			}
			if ( $preview && ! empty( $inst['display']['hide_in_editor'] ) ) {
				continue;
			}
			if ( ! FSCB_Conditions::passes( $inst ) ) {
				continue;
			}
			self::$floating[ $inst['id'] ] = FSCB_Settings::payload( $inst );
		}
		if ( self::$floating ) {
			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		}
	}

	/**
	 * Register assets (enqueued only when something is displayed).
	 */
	public static function register() {
		if ( wp_style_is( 'fscb-front', 'registered' ) ) {
			return;
		}
		wp_register_style( 'fscb-front', FSCB_URL . 'assets/css/front.css', array(), FSCB_VERSION );
		wp_register_script(
			'fscb-render',
			FSCB_URL . 'assets/js/render.js',
			array(),
			FSCB_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	/**
	 * Enqueue assets and the custom CSS of the displayed instances.
	 */
	public static function enqueue() {
		self::register();
		wp_enqueue_style( 'fscb-front' );
		wp_enqueue_script( 'fscb-render' );

		static $done = array();
		$css         = '';
		foreach ( array_merge( self::$floating, self::$inline ) as $id => $inst ) {
			if ( isset( $done[ $id ] ) ) {
				continue;
			}
			$done[ $id ] = true;
			$css        .= $inst['advanced']['custom_css'] ?? '';
		}
		if ( '' !== trim( $css ) ) {
			wp_add_inline_style( 'fscb-front', wp_strip_all_tags( $css ) );
		}
	}

	/**
	 * [fscb id="fcpabc123" part="all|items|socials" align="start|center|end"]
	 * Renders a widget inline (e.g. inside a footer column / Elementor / WoodMart HTML block).
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'    => '',
				'part'  => 'all',
				'align' => '',
			),
			$atts,
			'fscb'
		);
		$inst = $atts['id'] ? FSCB_Settings::get( sanitize_key( $atts['id'] ) ) : null;
		if ( ! $inst ) {
			$all  = FSCB_Settings::all();
			$inst = $all ? FSCB_Settings::fill( reset( $all ) ) : null;
		}
		if ( ! $inst ) {
			return '';
		}
		self::$inline[ $inst['id'] ] = FSCB_Settings::payload( $inst );
		if ( ! did_action( 'wp_enqueue_scripts' ) ) {
			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		} else {
			self::enqueue();
		}
		$part  = in_array( $atts['part'], array( 'all', 'items', 'socials' ), true ) ? $atts['part'] : 'all';
		$align = in_array( $atts['align'], array( 'start', 'center', 'end' ), true ) ? $atts['align'] : '';
		// JSON_HEX_TAG/AMP encode < > & so the payload can never close the script element.
		$json = wp_json_encode( self::$inline[ $inst['id'] ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
		return '<div class="fcp-inline-slot" data-part="' . esc_attr( $part ) . '"' . ( $align ? ' data-align="' . esc_attr( $align ) . '"' : '' ) . '><script type="application/json">' . $json . '</script></div>';
	}

	/**
	 * Print the floating payload once, in the footer.
	 */
	public static function print_data() {
		if ( self::$printed || ! self::$floating ) {
			return;
		}
		self::$printed = true;
		$g             = FSCB_Settings::get_global();
		$data          = array(
			'bp'       => array(
				'tablet' => (int) $g['bp_tablet'],
				'mobile' => (int) $g['bp_mobile'],
			),
			'tz'       => (float) get_option( 'gmt_offset', 0 ),
			'floating' => array_values( self::$floating ),
		);
		// JSON_HEX_TAG/AMP encode < > & so the payload can never close the script element.
		$json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
		echo "\n<script id=\"fcp-data\" type=\"application/json\">" . $json . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON payload, see comment above.
	}
}
